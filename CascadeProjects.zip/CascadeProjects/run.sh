#!/bin/bash

# Clean and compile the project
mvn clean compile

# Run the application with JVM arguments
mvn exec:java -Dexec.mainClass="com.jetthruster.ui.EnhancedThrusterSimulationUI" \
    -Dexec.vmArgs="-Dadd-opens java.desktop/sun.awt=ALL-UNNAMED \
    -Dadd-opens java.desktop/java.awt=ALL-UNNAMED \
    -Dadd-opens java.desktop/javax.swing=ALL-UNNAMED" 