#!/bin/bash

# Create build directory
mkdir -p build

# Compile all Java files
javac -d build $(find src/main/java -name "*.java")

# Run the application
java -cp build com.jetthruster.Main
