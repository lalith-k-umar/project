# Jet Fighter Thruster Simulation System

A Java-based simulation system that models the behavior and performance of advanced jet thrusters. The system provides a realistic simulation of thruster performance incorporating various environmental factors and physical calculations.

## Features

- Real-time thruster performance simulation
- Interactive GUI with live performance graphs
- Environmental factors simulation (altitude, air density, temperature)
- Diagnostic system with real-time alerts
- Performance logging and monitoring
- Afterburner simulation
- Advanced physics-based calculations

## System Requirements

- Java 11 or higher
- Maven 3.6 or higher

## Building the Project

```bash
mvn clean install
```

## Running the Simulation

```bash
mvn exec:java -Dexec.mainClass="com.jetthruster.ui.ThrusterSimulationUI"
```

## Usage

1. Use the Thrust slider to control the thruster power (0-100%)
2. Adjust the Altitude slider to simulate different flight conditions
3. Toggle the Afterburner for maximum thrust
4. Monitor the performance graphs and diagnostic information in real-time

## Architecture

The system is built using the following key components:

- `Thruster`: Base abstract class for thruster implementations
- `TurbofanThruster`: Concrete implementation of a turbofan jet engine
- `FlightEnvironment`: Handles environmental calculations
- `DiagnosticSystem`: Monitors thruster health and generates alerts
- `PerformanceLogger`: Records and tracks performance metrics
- `ThrusterSimulationUI`: Interactive user interface with real-time visualization

## Contributing

Feel free to submit issues and enhancement requests.
