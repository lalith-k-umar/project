package com.jetthruster.model.fuel;

public enum FuelTankType {
    MAIN,
    AUXILIARY,
    RESERVE,
    EXTERNAL
}
