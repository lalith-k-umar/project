package com.jetthruster.model;

// This class demonstrates aggregation - thruster components can exist independently
public class ThrusterComponents {
    private final String compressorType;
    private final String turbineType;
    private final double inletArea;
    private final double exhaustArea;

    public ThrusterComponents(String compressorType, String turbineType, double inletArea, double exhaustArea) {
        this.compressorType = compressorType;
        this.turbineType = turbineType;
        this.inletArea = inletArea;
        this.exhaustArea = exhaustArea;
    }

    public String getCompressorType() {
        return compressorType;
    }

    public String getTurbineType() {
        return turbineType;
    }

    public double getInletArea() {
        return inletArea;
    }

    public double getExhaustArea() {
        return exhaustArea;
    }

    public double calculatePressureRatio(double temperature) {
        // Simplified pressure ratio calculation based on temperature
        return 1.0 + (temperature / 288.15) * 0.2;
    }
}
