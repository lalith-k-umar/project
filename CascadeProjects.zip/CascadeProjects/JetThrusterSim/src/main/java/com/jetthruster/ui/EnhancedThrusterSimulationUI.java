package com.jetthruster.ui;

import com.jetthruster.model.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class EnhancedThrusterSimulationUI extends JFrame {
    private final TurbofanThruster thruster;
    private final FlightEnvironment environment;
    private final DiagnosticSystem diagnostics;
    private final ThrusterVisualization visualization;
    
    private JSlider thrustSlider;
    private JSlider altitudeSlider;
    private JSlider temperatureSlider;
    private JTextArea diagnosticArea;
    private Timer updateTimer;
    private JLabel statusLabel;
    
    // Performance tracking
    private final XYSeries thrustSeries;
    private final XYSeries fuelSeries;
    private double timeElapsed = 0;
    private boolean isPaused = false;

    private PerformanceAnalysisPanel performancePanel;
    private JTabbedPane tabbedPane;
    private JPanel mainPanel;
    private JPanel diagnosticsPanel;
    private JPanel environmentalPanel;
    private JPanel dataLoggingPanel;

    public EnhancedThrusterSimulationUI() {
        super("Enhanced Jet Thruster Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 900);
        setLocationRelativeTo(null);

        // Initialize systems
        thruster = new TurbofanThruster(8.0);
        environment = new FlightEnvironment();
        diagnostics = new DiagnosticSystem();
        visualization = new ThrusterVisualization();
        
        // Initialize performance tracking
        thrustSeries = new XYSeries("Thrust");
        fuelSeries = new XYSeries("Fuel Consumption");

        // Initialize main panel
        mainPanel = new JPanel(new BorderLayout());

        setupMenuBar();
        setupUI();
        setupKeyboardShortcuts();
        startSimulation();
    }

    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem saveItem = new JMenuItem("Save Simulation Data");
        JMenuItem loadItem = new JMenuItem("Load Simulation Data");
        JMenuItem exitItem = new JMenuItem("Exit");
        
        saveItem.addActionListener(e -> saveSimulationData());
        loadItem.addActionListener(e -> loadSimulationData());
        exitItem.addActionListener(e -> System.exit(0));
        
        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // Simulation Menu
        JMenu simMenu = new JMenu("Simulation");
        JMenuItem pauseItem = new JMenuItem("Pause/Resume");
        JMenuItem resetItem = new JMenuItem("Reset Simulation");
        JMenuItem settingsItem = new JMenuItem("Simulation Settings");
        
        pauseItem.addActionListener(e -> togglePause());
        resetItem.addActionListener(e -> resetSimulation());
        settingsItem.addActionListener(e -> showSettings());
        
        simMenu.add(pauseItem);
        simMenu.add(resetItem);
        simMenu.add(settingsItem);

        // Help Menu
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        JMenuItem manualItem = new JMenuItem("User Manual");
        
        aboutItem.addActionListener(e -> showAbout());
        manualItem.addActionListener(e -> showManual());
        
        helpMenu.add(aboutItem);
        helpMenu.add(manualItem);

        menuBar.add(fileMenu);
        menuBar.add(simMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
    }

    private void setupKeyboardShortcuts() {
        // Pause/Resume shortcut
        getRootPane().registerKeyboardAction(
            e -> togglePause(),
            KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        // Reset shortcut
        getRootPane().registerKeyboardAction(
            e -> resetSimulation(),
            KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );
    }

    private void setupUI() {
        // Left panel for controls
        JPanel controlPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createTitledBorder("Controls"));
        
        // Thrust control
        thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setBorder(BorderFactory.createTitledBorder("Thrust Level (%)"));
        thrustSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(thrustSlider);

        // Altitude control
        altitudeSlider = new JSlider(0, 15000, 0);
        altitudeSlider.setBorder(BorderFactory.createTitledBorder("Altitude (m)"));
        altitudeSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(altitudeSlider);

        // Temperature control
        temperatureSlider = new JSlider(-50, 50, 15);
        temperatureSlider.setBorder(BorderFactory.createTitledBorder("Temperature (°C)"));
        temperatureSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(temperatureSlider);

        // Diagnostic area
        diagnosticArea = new JTextArea(10, 30);
        diagnosticArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(diagnosticArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Diagnostics"));
        controlPanel.add(scrollPane);

        // Add control panel to main panel
        mainPanel.add(controlPanel, BorderLayout.WEST);

        // Create and setup tabbed pane
        createTabbedPane();

        // Add status bar
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(BorderFactory.createEtchedBorder());
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Handle cleanup on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopSimulation();
            }
        });
    }

    private void createTabbedPane() {
        tabbedPane = new JTabbedPane();
        
        // Create panels
        createPerformancePanel();
        createDiagnosticsPanel();
        createEnvironmentalPanel();
        createDataLoggingPanel();
        
        // Add panels to tabbed pane
        tabbedPane.addTab("Performance Analysis", performancePanel);
        tabbedPane.addTab("System Diagnostics", diagnosticsPanel);
        tabbedPane.addTab("Environmental Settings", environmentalPanel);
        tabbedPane.addTab("Data Logging", dataLoggingPanel);
        
        // Add tab change listener
        tabbedPane.addChangeListener(e -> {
            int selectedIndex = tabbedPane.getSelectedIndex();
            if (selectedIndex == 0) { // Performance Analysis tab
                performancePanel.startSimulation();
            } else {
                performancePanel.stopSimulation();
            }
        });
        
        // Add to main panel
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
    }

    private void createPerformancePanel() {
        performancePanel = new PerformanceAnalysisPanel(thruster);
        performancePanel.setPreferredSize(new Dimension(800, 600));
    }

    private void createDiagnosticsPanel() {
        diagnosticsPanel = new JPanel();
        diagnosticsPanel.setLayout(new BorderLayout());
        diagnosticsPanel.add(new JLabel("System Diagnostics"), BorderLayout.NORTH);
        // Add more diagnostic components here
    }

    private void createEnvironmentalPanel() {
        environmentalPanel = new JPanel();
        environmentalPanel.setLayout(new BorderLayout());
        environmentalPanel.add(new JLabel("Environmental Settings"), BorderLayout.NORTH);
        // Add more environmental controls here
    }

    private void createDataLoggingPanel() {
        dataLoggingPanel = new JPanel();
        dataLoggingPanel.setLayout(new BorderLayout());
        dataLoggingPanel.add(new JLabel("Data Logging"), BorderLayout.NORTH);
        // Add more data logging components here
    }

    private void startSimulation() {
        updateTimer = new Timer(50, e -> {
            if (!isPaused) {
                updateSimulation();
            }
        });
        updateTimer.start();
        setVisible(true);
        
        // Start performance panel if it's visible
        if (tabbedPane != null && tabbedPane.getSelectedIndex() == 0) {
            performancePanel.startSimulation();
        }
    }

    private void updateSimulation() {
        // Update thruster and environment
        thruster.setThrustLevel(thrustSlider.getValue() / 100.0);
        environment.setAltitude(altitudeSlider.getValue());
        environment.setTemperature(temperatureSlider.getValue());
        
        // Update systems
        environment.update();
        thruster.calculateThrust(environment);
        diagnostics.checkSystem(thruster, environment);

        // Update visualization
        visualization.setThrustLevel((float)thruster.getThrustLevel());

        // Update performance tracking
        timeElapsed += 0.05; // 50ms update interval
        thrustSeries.add(timeElapsed, thruster.getCurrentThrust());
        fuelSeries.add(timeElapsed, thruster.getFuelConsumption());
        
        // Keep only last 100 seconds of data
        if (timeElapsed > 100) {
            thrustSeries.delete(0, 0);
            fuelSeries.delete(0, 0);
        }

        // Update diagnostic display
        StringBuilder status = new StringBuilder();
        status.append(String.format("Thrust Level: %.1f%%\n", thruster.getThrustLevel() * 100));
        status.append(String.format("Current Thrust: %.2f kN\n", thruster.getCurrentThrust()));
        status.append(String.format("Altitude: %.0f m\n", environment.getAltitude()));
        status.append(String.format("Temperature: %.1f°C\n", environment.getTemperature()));
        status.append(String.format("Fuel Consumption: %.2f kg/s\n", thruster.getFuelConsumption()));
        status.append("\nDiagnostic Message:\n");
        status.append(diagnostics.getLastDiagnosticMessage());
        
        diagnosticArea.setText(status.toString());
        
        // Update status bar
        statusLabel.setText(String.format("Time: %.1f s | Thrust: %.1f kN | Altitude: %.0f m", 
            timeElapsed, thruster.getCurrentThrust(), environment.getAltitude()));
    }

    private void stopSimulation() {
        if (updateTimer != null) {
            updateTimer.stop();
        }
        if (visualization != null) {
            visualization.stop();
        }
        dispose();
    }

    // Menu action handlers
    private void togglePause() {
        isPaused = !isPaused;
        statusLabel.setText(isPaused ? "Simulation Paused" : "Simulation Running");
    }

    private void resetSimulation() {
        timeElapsed = 0;
        thrustSeries.clear();
        fuelSeries.clear();
        thrustSlider.setValue(0);
        altitudeSlider.setValue(0);
        temperatureSlider.setValue(15);
        isPaused = false;
        statusLabel.setText("Simulation Reset");
        
        // Reset performance panel
        performancePanel.stopSimulation();
        performancePanel.startSimulation();
    }

    private void showSettings() {
        JDialog dialog = new JDialog(this, "Simulation Settings", true);
        dialog.setLayout(new GridLayout(0, 2, 5, 5));
        
        // Add settings controls here
        dialog.add(new JLabel("Update Rate (ms):"));
        JTextField updateRateField = new JTextField("50");
        dialog.add(updateRateField);
        
        dialog.add(new JLabel("Max Data Points:"));
        JTextField maxPointsField = new JTextField("2000");
        dialog.add(maxPointsField);
        
        JButton applyButton = new JButton("Apply");
        applyButton.addActionListener(e -> {
            try {
                int updateRate = Integer.parseInt(updateRateField.getText());
                updateTimer.setDelay(updateRate);
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter valid numbers", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        dialog.add(applyButton);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void showAbout() {
        JOptionPane.showMessageDialog(this,
            "Enhanced Jet Thruster Simulation\nVersion 1.0\n\n" +
            "A comprehensive simulation of a turbofan thruster system\n" +
            "with real-time visualization and performance monitoring.",
            "About",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void showManual() {
        JDialog dialog = new JDialog(this, "User Manual", true);
        dialog.setSize(600, 400);
        
        JTextArea manualText = new JTextArea();
        manualText.setEditable(false);
        manualText.setText(
            "Enhanced Jet Thruster Simulation Manual\n\n" +
            "Controls:\n" +
            "- Use sliders to adjust thrust, altitude, and temperature\n" +
            "- Space: Pause/Resume simulation\n" +
            "- Ctrl+R: Reset simulation\n\n" +
            "Menu Options:\n" +
            "- File: Save/Load simulation data\n" +
            "- Simulation: Control simulation parameters\n" +
            "- Help: Access this manual and about information\n\n" +
            "The simulation shows real-time performance data and\n" +
            "3D visualization of the thruster system."
        );
        
        dialog.add(new JScrollPane(manualText));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void saveSimulationData() {
        // TODO: Implement save functionality
        JOptionPane.showMessageDialog(this, "Save functionality to be implemented");
    }

    private void loadSimulationData() {
        // TODO: Implement load functionality
        JOptionPane.showMessageDialog(this, "Load functionality to be implemented");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EnhancedThrusterSimulationUI());
    }
}
