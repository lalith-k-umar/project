package com.jetthruster.model;

import java.util.ArrayList;
import java.util.List;

public class DiagnosticSystem {
    private double temperatureThreshold;
    private double fuelConsumptionThreshold;
    private String lastDiagnosticMessage;
    private final List<ThrusterAlert> warnings;
    private boolean running;

    public DiagnosticSystem() {
        this.temperatureThreshold = 1000.0; // Celsius
        this.fuelConsumptionThreshold = 2.0; // kg/s
        this.lastDiagnosticMessage = "System initialized";
        this.warnings = new ArrayList<>();
        this.running = false;
    }

    public void checkSystem(TurbofanThruster thruster, FlightEnvironment environment) {
        StringBuilder diagnostics = new StringBuilder();

        // Check temperature
        double currentTemp = environment.getTemperature();
        if (currentTemp > temperatureThreshold) {
            diagnostics.append("WARNING: Temperature exceeds threshold. ");
            addWarning(new ThrusterAlert(AlertLevel.WARNING, "Temperature exceeds threshold"));
        }

        // Check fuel consumption
        double fuelConsumption = thruster.getFuelConsumption();
        if (fuelConsumption > fuelConsumptionThreshold) {
            diagnostics.append("WARNING: High fuel consumption. ");
            addWarning(new ThrusterAlert(AlertLevel.WARNING, "High fuel consumption"));
        }

        // Check thrust efficiency
        double thrustLevel = thruster.getThrustLevel();
        double currentThrust = thruster.getCurrentThrust();
        if (thrustLevel > 0.8 && currentThrust < 80.0) {
            diagnostics.append("WARNING: Low thrust efficiency. ");
            addWarning(new ThrusterAlert(AlertLevel.WARNING, "Low thrust efficiency"));
        }

        // Set diagnostic message
        lastDiagnosticMessage = diagnostics.length() > 0 ? 
            diagnostics.toString() : "All systems nominal";
    }

    public String getLastDiagnosticMessage() {
        return lastDiagnosticMessage;
    }

    public void setTemperatureThreshold(double threshold) {
        this.temperatureThreshold = threshold;
    }

    public void setFuelConsumptionThreshold(double threshold) {
        this.fuelConsumptionThreshold = threshold;
    }

    public void start() {
        this.running = true;
    }

    public void stop() {
        this.running = false;
    }

    public void addWarning(ThrusterAlert alert) {
        if (running) {
            warnings.add(alert);
        }
    }

    public List<ThrusterAlert> getWarnings() {
        return new ArrayList<>(warnings);
    }

    public boolean isRunning() {
        return running;
    }
}
