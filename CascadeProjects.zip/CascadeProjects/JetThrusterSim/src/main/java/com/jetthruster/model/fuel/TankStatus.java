package com.jetthruster.model.fuel;

public enum TankStatus {
    OPERATIONAL,
    WARNING,
    CRITICAL,
    MALFUNCTION
}
