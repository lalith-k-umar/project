package com.jetthruster.model;

public class Thruster {
    protected double maxThrust;
    protected double currentThrust;
    protected double fuelConsumption;
    protected double temperature;
    protected ThrusterState state;
    protected String thrusterType;

    public Thruster() {
        this.maxThrust = 100000; // 100 kN default max thrust
        this.thrusterType = "Standard Jet Thruster";
        this.currentThrust = 0;
        this.fuelConsumption = 0;
        this.temperature = 20; // Default temperature in Celsius
        this.state = ThrusterState.IDLE;
    }

    public void calculateThrust(FlightEnvironment environment) {
        // Simple thrust calculation based on altitude
        double altitudeFactor = Math.max(0.5, 1.0 - (environment.getAltitude() / 40000.0));
        currentThrust = maxThrust * altitudeFactor;
        temperature = 20 + (currentThrust / maxThrust) * 1000; // Temperature increases with thrust
    }

    public void adjustThrust(double percentage) {
        if (percentage < 0) percentage = 0;
        if (percentage > 100) percentage = 100;
        currentThrust = (maxThrust * percentage) / 100.0;
        temperature = 20 + (currentThrust / maxThrust) * 1000;
    }

    public double calculateFuelConsumption() {
        return (currentThrust / maxThrust) * 50.0; // kg/s of fuel consumption
    }

    public double getCurrentThrust() {
        return currentThrust;
    }

    public double getMaxThrust() {
        return maxThrust;
    }

    public ThrusterState getState() {
        return state;
    }

    public void setState(ThrusterState state) {
        this.state = state;
    }

    public double getTemperature() {
        return temperature;
    }

    public String getThrusterType() {
        return thrusterType;
    }
}

enum ThrusterState {
    IDLE, STARTUP, CRUISE, AFTERBURNER, SHUTDOWN, MAINTENANCE
}
