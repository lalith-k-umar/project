package com.jetthruster.visualization;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.*;

public class ThrusterVisualization {
    private final JPanel visualizationPanel;
    private final Timer animationTimer;
    private double thrustLevel = 0.0;
    private boolean afterburnerEnabled = false;
    private double rotationAngle = 0.0;
    private double flameSize = 1.0;
    private Color thrusterColor = new Color(50, 50, 50);
    private Color flameColor = new Color(255, 140, 0);

    public ThrusterVisualization() {
        visualizationPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                drawThruster(g2d);
            }
        };
        visualizationPanel.setPreferredSize(new Dimension(600, 400));
        visualizationPanel.setBackground(Color.BLACK);

        animationTimer = new Timer(50, e -> {
            rotationAngle += 0.1;
            flameSize = 1.0 + 0.2 * Math.sin(rotationAngle);
            visualizationPanel.repaint();
        });
    }

    private void drawThruster(Graphics2D g2d) {
        int centerX = visualizationPanel.getWidth() / 2;
        int centerY = visualizationPanel.getHeight() / 2;
        
        // Save the current transform
        AffineTransform oldTransform = g2d.getTransform();
        
        // Translate to center and rotate
        g2d.translate(centerX, centerY);
        g2d.rotate(rotationAngle);
        
        // Draw main thruster body
        g2d.setColor(thrusterColor);
        g2d.fill(new Rectangle2D.Double(-40, -20, 80, 40));
        
        // Draw intake
        g2d.setColor(Color.DARK_GRAY);
        g2d.fill(new Ellipse2D.Double(-50, -25, 20, 50));
        
        // Draw nozzle
        g2d.setColor(Color.GRAY);
        int[] xPoints = {40, 60, 60, 40};
        int[] yPoints = {-20, -15, 15, 20};
        g2d.fillPolygon(xPoints, yPoints, 4);
        
        // Draw flame if thrust > 0
        if (thrustLevel > 0) {
            Color flameColorWithAlpha = new Color(
                flameColor.getRed(),
                flameColor.getGreen(),
                flameColor.getBlue(),
                (int)(255 * thrustLevel)
            );
            g2d.setColor(flameColorWithAlpha);
            
            double flameLength = 40 * thrustLevel * flameSize;
            if (afterburnerEnabled) {
                flameLength *= 1.5;
                g2d.setColor(new Color(0, 191, 255, (int)(255 * thrustLevel)));
            }
            
            int[] flameX = {60, 60 + (int)flameLength, 60};
            int[] flameY = {-10, 0, 10};
            g2d.fillPolygon(flameX, flameY, 3);
        }
        
        // Draw turbine blades
        g2d.setColor(Color.LIGHT_GRAY);
        for (int i = 0; i < 8; i++) {
            g2d.rotate(Math.PI / 4);
            g2d.fill(new Rectangle2D.Double(-2, -15, 4, 30));
        }
        
        // Restore the original transform
        g2d.setTransform(oldTransform);
        
        // Draw performance metrics
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
        g2d.drawString(String.format("Thrust: %.1f%%", thrustLevel * 100), 10, 20);
        g2d.drawString(String.format("Afterburner: %s", afterburnerEnabled ? "ON" : "OFF"), 10, 40);
    }

    public JPanel getVisualizationPanel() {
        return visualizationPanel;
    }

    public void startAnimation() {
        animationTimer.start();
    }

    public void stopAnimation() {
        animationTimer.stop();
    }

    public void updateThrustLevel(double level) {
        this.thrustLevel = Math.max(0.0, Math.min(1.0, level));
    }

    public void setAfterburnerEnabled(boolean enabled) {
        this.afterburnerEnabled = enabled;
    }

    public void updateSimulation(double speed, double altitude, double temperature) {
        // Adjust visualization based on simulation parameters
        double tempFactor = (temperature + 50) / 100.0; // Normalize temperature from -50 to +50
        flameColor = new Color(
            255,
            (int)(140 * tempFactor),
            (int)(Math.max(0, Math.min(255, altitude / 1000.0)))
        );
        
        // Adjust rotation speed based on actual speed
        rotationAngle += speed * 0.001;
    }
}
