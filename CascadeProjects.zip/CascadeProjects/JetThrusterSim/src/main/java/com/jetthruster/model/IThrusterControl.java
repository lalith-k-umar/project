package com.jetthruster.model;

public interface IThrusterControl {
    void setThrustLevel(double level);
    double getThrustLevel();
    void setAfterburnerEnabled(boolean enabled);
    boolean isAfterburnerEnabled();
    void calculateThrust(FlightEnvironment environment);
    double getCurrentThrust();
    double getFuelConsumption();
}
