package com.jetthruster.model.mission;

public enum MissionStatus {
    READY,
    IN_PROGRESS,
    COMPLETED,
    ABORTED
}
