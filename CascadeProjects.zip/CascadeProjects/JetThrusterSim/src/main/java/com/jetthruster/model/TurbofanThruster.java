package com.jetthruster.model;

public class TurbofanThruster extends AbstractThruster {
    private final double bypassRatio;
    private final ThrusterComponents components; // Aggregation
    private final ThrusterMonitor monitor; // Composition

    public TurbofanThruster(double bypassRatio) {
        super();
        if (bypassRatio <= 0) {
            throw new IllegalArgumentException("Bypass ratio must be positive");
        }
        this.bypassRatio = bypassRatio;
        
        // Initialize components with default values
        this.components = new ThrusterComponents(
            "Axial Flow",
            "High-Bypass Turbofan",
            2.5,
            1.8
        );
        
        // Initialize monitor (composition)
        this.monitor = new ThrusterMonitor(this);
    }

    @Override
    public void setThrustLevel(double level) {
        super.setThrustLevel(level);
    }

    @Override
    public double getThrustLevel() {
        return super.getThrustLevel();
    }

    @Override
    public void setAfterburnerEnabled(boolean enabled) {
        super.setAfterburnerEnabled(enabled);
    }

    @Override
    public boolean isAfterburnerEnabled() {
        return super.isAfterburnerEnabled();
    }

    @Override
    public void calculateThrust(FlightEnvironment environment) {
        if (environment == null) {
            throw new IllegalArgumentException("Flight environment cannot be null");
        }
        
        double baseThrust = 100.0 * super.getThrustLevel(); // Base thrust in kN
        double densityFactor = environment.getAirDensity() / 1.225; // Sea level density ratio
        
        // Apply environmental effects and component characteristics
        double pressureRatio = components.calculatePressureRatio(environment.getTemperature());
        double environmentalThrust = baseThrust * densityFactor * pressureRatio;
        
        // Apply bypass ratio effects
        double bypassEffect = 1.0 + (bypassRatio * 0.1);
        environmentalThrust *= bypassEffect;
        
        // Apply afterburner if enabled
        if (super.isAfterburnerEnabled()) {
            environmentalThrust *= 1.5;
        }
        
        super.setCurrentThrust(environmentalThrust);
        
        // Update monitor status
        monitor.updateStatus(environment);
    }

    @Override
    public double getCurrentThrust() {
        return super.getCurrentThrust();
    }

    @Override
    public double getFuelConsumption() {
        return super.getFuelConsumption();
    }

    @Override
    protected void calculateFuelConsumption() {
        // Base fuel consumption based on thrust level
        double baseFuelConsumption = super.getThrustLevel() * 0.5; // kg/s
        
        // Additional consumption for afterburner
        if (super.isAfterburnerEnabled()) {
            baseFuelConsumption *= 2.0;
        }
        
        // Adjust for bypass ratio (more efficient with higher bypass)
        double bypassEfficiency = 1.0 - (bypassRatio * 0.05);
        super.setFuelConsumption(baseFuelConsumption * bypassEfficiency);
    }

    public boolean isWarning() {
        return monitor.isWarning();
    }

    public double getBypassRatio() {
        return bypassRatio;
    }
}
