package com.jetthruster.model.mission;

public enum PhaseType {
    TAKEOFF,
    CLIMB,
    CRUISE,
    COMBAT,
    DESCENT,
    LANDING
}
