package com.jetthruster.model;

public class ThrusterAlert {
    private final AlertLevel level;
    private final String message;
    private final long timestamp;

    public ThrusterAlert(AlertLevel level, String message) {
        this.level = level;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
    }

    public AlertLevel getLevel() {
        return level;
    }

    public String getMessage() {
        return message;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
