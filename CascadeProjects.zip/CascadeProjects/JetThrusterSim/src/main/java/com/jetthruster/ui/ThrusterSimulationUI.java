package com.jetthruster.ui;

import com.jetthruster.model.*;
import com.jetthruster.model.weather.WeatherSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ThrusterSimulationUI extends JFrame {
    private final TurbofanThruster thruster;
    private final FlightEnvironment environment;
    private final DiagnosticSystem diagnostics;
    private final WeatherSystem weatherSystem;
    private final ThrusterVisualization visualization;
    
    private JSlider thrustSlider;
    private JSlider altitudeSlider;
    private JSlider temperatureSlider;
    private JTextArea diagnosticArea;
    private Timer updateTimer;

    public ThrusterSimulationUI() {
        super("Jet Thruster Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);

        // Initialize systems
        thruster = new TurbofanThruster(8.0);
        environment = new FlightEnvironment();
        diagnostics = new DiagnosticSystem();
        weatherSystem = new WeatherSystem();
        visualization = new ThrusterVisualization();

        setupUI();
        startSimulation();
    }

    private void setupUI() {
        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Control panel on the left
        JPanel controlPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createTitledBorder("Controls"));
        
        // Thrust control
        thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setBorder(BorderFactory.createTitledBorder("Thrust Level (%)"));
        thrustSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(thrustSlider);

        // Altitude control
        altitudeSlider = new JSlider(0, 15000, 0);
        altitudeSlider.setBorder(BorderFactory.createTitledBorder("Altitude (m)"));
        altitudeSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(altitudeSlider);

        // Temperature control
        temperatureSlider = new JSlider(-50, 50, 15);
        temperatureSlider.setBorder(BorderFactory.createTitledBorder("Temperature (°C)"));
        temperatureSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(temperatureSlider);

        // Diagnostic area
        diagnosticArea = new JTextArea(10, 30);
        diagnosticArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(diagnosticArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Diagnostics"));
        controlPanel.add(scrollPane);

        // Add visualization to center
        JPanel visualizationPanel = new JPanel(new BorderLayout());
        visualizationPanel.setBorder(BorderFactory.createTitledBorder("3D Visualization"));
        visualizationPanel.add(visualization.getCanvas());

        // Add panels to main panel
        mainPanel.add(controlPanel, BorderLayout.WEST);
        mainPanel.add(visualizationPanel, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // Handle cleanup on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopSimulation();
            }
        });
    }

    private void startSimulation() {
        // Create timer for periodic updates
        updateTimer = new Timer(50, e -> updateSimulation());
        updateTimer.start();
        setVisible(true);
    }

    private void updateSimulation() {
        // Update thruster and environment
        thruster.setThrustLevel(thrustSlider.getValue() / 100.0);
        environment.setAltitude(altitudeSlider.getValue());
        environment.setTemperature(temperatureSlider.getValue());
        
        // Update systems
        environment.update();
        thruster.calculateThrust(environment);
        diagnostics.checkSystem(thruster, environment);

        // Update visualization
        visualization.setThrustLevel((float)thruster.getThrustLevel());

        // Update diagnostic display
        StringBuilder status = new StringBuilder();
        status.append(String.format("Thrust Level: %.1f%%\n", thruster.getThrustLevel() * 100));
        status.append(String.format("Current Thrust: %.2f kN\n", thruster.getCurrentThrust()));
        status.append(String.format("Altitude: %.0f m\n", environment.getAltitude()));
        status.append(String.format("Temperature: %.1f°C\n", environment.getTemperature()));
        status.append(String.format("Fuel Consumption: %.2f kg/s\n", thruster.getFuelConsumption()));
        status.append("\nDiagnostic Message:\n");
        status.append(diagnostics.getLastDiagnosticMessage());
        
        diagnosticArea.setText(status.toString());
    }

    private void stopSimulation() {
        if (updateTimer != null) {
            updateTimer.stop();
        }
        if (visualization != null) {
            visualization.stop();
        }
        dispose();
    }
}
