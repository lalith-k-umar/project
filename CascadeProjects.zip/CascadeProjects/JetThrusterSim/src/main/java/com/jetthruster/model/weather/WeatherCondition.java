package com.jetthruster.model.weather;

public class WeatherCondition {
    private double temperature;
    private double humidity;
    private double pressure;
    private double windSpeed;
    private double windDirection;
    private double turbulenceLevel;
    private double altitude;

    public WeatherCondition() {
        // Default values
        this.temperature = 15.0;
        this.humidity = 60.0;
        this.pressure = 1013.25;
        this.windSpeed = 0.0;
        this.windDirection = 0.0;
        this.turbulenceLevel = 0.0;
        this.altitude = 0.0;
    }

    public WeatherCondition(double temperature, double humidity, double pressure,
                          double windSpeed, double windDirection, double turbulenceLevel,
                          double altitude) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        this.windSpeed = windSpeed;
        this.windDirection = windDirection;
        this.turbulenceLevel = turbulenceLevel;
        this.altitude = altitude;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getHumidity() {
        return humidity;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }

    public double getPressure() {
        return pressure;
    }

    public void setPressure(double pressure) {
        this.pressure = pressure;
    }

    public double getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(double windSpeed) {
        this.windSpeed = windSpeed;
    }

    public double getWindDirection() {
        return windDirection;
    }

    public void setWindDirection(double windDirection) {
        this.windDirection = windDirection;
    }

    public double getTurbulenceLevel() {
        return turbulenceLevel;
    }

    public void setTurbulenceLevel(double turbulenceLevel) {
        this.turbulenceLevel = turbulenceLevel;
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    @Override
    public String toString() {
        return String.format(
            "WeatherCondition[temp=%.1f°C, humidity=%.1f%%, pressure=%.1fhPa, " +
            "wind=%.1fm/s@%.1f°, turbulence=%.2f, altitude=%.1fm]",
            temperature, humidity, pressure, windSpeed, windDirection, 
            turbulenceLevel, altitude
        );
    }
}
