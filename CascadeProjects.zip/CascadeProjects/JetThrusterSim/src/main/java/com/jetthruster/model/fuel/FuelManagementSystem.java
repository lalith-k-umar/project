package com.jetthruster.model.fuel;

import com.jetthruster.exception.FuelSystemException;
import java.util.ArrayList;
import java.util.List;

public class FuelManagementSystem implements IFuelSystem {
    private final List<FuelTank> tanks;
    private final List<FuelSystemListener> listeners;

    public FuelManagementSystem() {
        this.tanks = new ArrayList<>();
        this.listeners = new ArrayList<>();
        initialize();
    }

    public void initialize() {
        // Initialize with a main tank and auxiliary tank
        try {
            addTank(new FuelTank("Main Tank", 5000.0, FuelTankType.MAIN));
            addTank(new FuelTank("Auxiliary Tank", 2000.0, FuelTankType.AUXILIARY));
        } catch (FuelSystemException e) {
            // Log initialization error
            System.err.println("Failed to initialize fuel system: " + e.getMessage());
        }
    }

    @Override
    public void addTank(FuelTank tank) throws FuelSystemException {
        if (tank == null) {
            throw new FuelSystemException("Cannot add null tank");
        }
        tanks.add(tank);
        notifyListeners(new FuelSystemEvent(tank, "TANK_ADDED", 0, tank.getCurrentLevel()));
    }

    @Override
    public void removeTank(FuelTank tank) throws FuelSystemException {
        if (!tanks.remove(tank)) {
            throw new FuelSystemException("Tank not found in system");
        }
        notifyListeners(new FuelSystemEvent(tank, "TANK_REMOVED", tank.getCurrentLevel(), 0));
    }

    @Override
    public void updateFuelStatus() {
        for (FuelTank tank : tanks) {
            double oldLevel = tank.getCurrentLevel();
            tank.updateStatus();
            if (oldLevel != tank.getCurrentLevel()) {
                notifyListeners(new FuelSystemEvent(tank, "LEVEL_CHANGED", oldLevel, tank.getCurrentLevel()));
            }
        }
    }

    public void updateFuel(double amount) {
        double remainingAmount = amount;
        for (FuelTank tank : tanks) {
            if (tank.getCurrentLevel() > 0) {
                double consumed = Math.min(remainingAmount, tank.getCurrentLevel());
                tank.consumeFuel(consumed);
                remainingAmount -= consumed;
                if (remainingAmount <= 0) break;
            }
        }
        updateFuelStatus();
    }

    public double getCurrentFuelMass() {
        return tanks.stream()
                   .mapToDouble(tank -> tank.getCurrentLevel() * tank.getFuelDensity())
                   .sum();
    }

    @Override
    public List<FuelTank> getTanks() {
        return new ArrayList<>(tanks);
    }

    @Override
    public double getTotalFuelLevel() {
        return tanks.stream()
                   .mapToDouble(FuelTank::getCurrentLevel)
                   .sum();
    }

    @Override
    public boolean hasSufficientFuel(double requiredAmount) throws FuelSystemException {
        if (requiredAmount < 0) {
            throw new FuelSystemException("Required amount cannot be negative");
        }
        return getTotalFuelLevel() >= requiredAmount;
    }

    public double getFuelLevel() {
        double totalCapacity = tanks.stream()
                                  .mapToDouble(FuelTank::getCapacity)
                                  .sum();
        double currentTotal = getTotalFuelLevel();
        return totalCapacity > 0 ? currentTotal / totalCapacity : 0.0;
    }

    public FuelTankStatus getStatus() {
        double level = getFuelLevel();
        double mainTankLevel = tanks.stream()
                                  .filter(t -> t.getType() == FuelTankType.MAIN)
                                  .findFirst()
                                  .map(FuelTank::getCurrentLevel)
                                  .orElse(0.0);
        double auxTankLevel = tanks.stream()
                                 .filter(t -> t.getType() == FuelTankType.AUXILIARY)
                                 .findFirst()
                                 .map(FuelTank::getCurrentLevel)
                                 .orElse(0.0);
        return new FuelTankStatus("Combined Status", level, mainTankLevel + auxTankLevel, FuelTankType.MAIN);
    }

    @Override
    public void addListener(FuelSystemListener listener) throws FuelSystemException {
        if (listener == null) {
            throw new FuelSystemException("Cannot add null listener");
        }
        listeners.add(listener);
    }

    @Override
    public void removeListener(FuelSystemListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners(FuelSystemEvent event) {
        for (FuelSystemListener listener : listeners) {
            listener.onFuelSystemEvent(event, this);
        }
    }
}

class FuelMixture {
    private double fuelToAirRatio;
    private double efficiencyFactor;

    public FuelMixture() {
        this.fuelToAirRatio = 14.7; // Stoichiometric ratio
        this.efficiencyFactor = 1.0;
    }

    public void adjustMixture(double altitude, double temperature) {
        // Adjust mixture based on environmental conditions
        double altitudeFactor = Math.max(0.8, 1.0 - (altitude / 50000.0));
        double temperatureFactor = Math.max(0.9, 1.0 - Math.abs(temperature - 15) / 100.0);
        
        this.fuelToAirRatio = 14.7 * altitudeFactor; // Used to adjust mixture
        this.efficiencyFactor = altitudeFactor * temperatureFactor;
    }

    public double getEfficiencyFactor() {
        return efficiencyFactor;
    }

    public double getFuelToAirRatio() {
        return fuelToAirRatio;
    }
}

class FuelFlowRate {
    private double baseFlowRate;
    private double efficiencyFactor;

    public FuelFlowRate() {
        this.baseFlowRate = 1.0;
        this.efficiencyFactor = 1.0;
    }

    public double calculateConsumption(double requestedAmount, double throttlePercentage) {
        double throttleFactor = 0.5 + (throttlePercentage / 200.0); // Non-linear relationship
        return requestedAmount * throttleFactor * efficiencyFactor * baseFlowRate;
    }

    public double getEfficiencyFactor() {
        return efficiencyFactor;
    }
}
