package com.jetthruster.exception;

public class ThrusterException extends Exception {
    public ThrusterException(String message) {
        super(message);
    }

    public ThrusterException(String message, Throwable cause) {
        super(message, cause);
    }
} 