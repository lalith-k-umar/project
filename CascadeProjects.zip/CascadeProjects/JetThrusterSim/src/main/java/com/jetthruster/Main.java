package com.jetthruster;

import com.jetthruster.ui.MainUI;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        try {
            // Set system look and feel for better UI experience
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            SwingUtilities.invokeLater(() -> {
                try {
                    // Create and show main UI
                    MainUI ui = new MainUI();
                    ui.setLocationRelativeTo(null); // Center on screen
                    ui.setVisible(true);
                } catch (Exception e) {
                    System.err.println("Error starting application: " + e.getMessage());
                    e.printStackTrace();
                    System.exit(1);
                }
            });
        } catch (Exception e) {
            System.err.println("Error setting look and feel: " + e.getMessage());
            // Continue with default look and feel
        }
    }
}
