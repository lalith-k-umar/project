package com.jetthruster.model.mission;

public class MissionPhase {
    private final String name;
    private final double targetAltitude;
    private final double targetSpeed;
    private final double duration;
    private double elapsedTime;
    private boolean complete;
    private final PhaseType type;

    public MissionPhase(String name, double targetAltitude, double targetSpeed, double duration, PhaseType type) {
        this.name = name;
        this.targetAltitude = targetAltitude;
        this.targetSpeed = targetSpeed;
        this.duration = duration;
        this.type = type;
        this.elapsedTime = 0;
        this.complete = false;
    }

    public void updateProgress(double currentAltitude, double currentSpeed) {
        if (complete) return;

        boolean altitudeReached = Math.abs(currentAltitude - targetAltitude) < 100;
        boolean speedReached = Math.abs(currentSpeed - targetSpeed) < 10;

        if (altitudeReached && speedReached) {
            elapsedTime += 1.0; // Assume 1-second update interval
        }

        if (elapsedTime >= duration) {
            complete = true;
        }
    }

    public double getCompletionPercentage() {
        return Math.min(100.0, (elapsedTime / duration) * 100.0);
    }

    public boolean isComplete() {
        return complete;
    }

    public String getName() {
        return name;
    }

    public double getTargetAltitude() {
        return targetAltitude;
    }

    public double getTargetSpeed() {
        return targetSpeed;
    }

    public PhaseType getType() {
        return type;
    }

    public double getDuration() {
        return duration;
    }

    public double getElapsedTime() {
        return elapsedTime;
    }
}
