package com.jetthruster.ui;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.glu.GLUquadric;
import com.jogamp.opengl.util.FPSAnimator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Thruster3DPanel extends JPanel implements GLEventListener, KeyListener {
    private static final int FPS = 60;
    private GLCanvas canvas;
    private float thrustLevel = 0.0f;
    private float rotationAngle = 0.0f;
    private float zoom = -20.0f;
    private float rotX = 20.0f;
    private float rotY = 0.0f;
    private Point lastPoint;
    private GLU glu;
    private GLUquadric quadric;
    private FPSAnimator animator;
    private boolean isSimulationRunning = false;
    private float[] particlePositions;
    private float[] particleVelocities;
    private float[] particleSizes;
    private static final int NUM_PARTICLES = 100;

    public Thruster3DPanel() {
        setLayout(new BorderLayout());
        
        // Initialize particle system
        particlePositions = new float[NUM_PARTICLES * 3];
        particleVelocities = new float[NUM_PARTICLES * 3];
        particleSizes = new float[NUM_PARTICLES];
        initializeParticles();
        
        // Create OpenGL profile and capabilities
        GLProfile glProfile = GLProfile.getDefault();
        GLCapabilities glCapabilities = new GLCapabilities(glProfile);
        glCapabilities.setDoubleBuffered(true);
        glCapabilities.setHardwareAccelerated(true);

        // Create canvas
        canvas = new GLCanvas(glCapabilities);
        canvas.addGLEventListener(this);
        canvas.addKeyListener(this);
        canvas.setFocusable(true);

        // Create control panel
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        // Add thrust slider
        JSlider thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setMajorTickSpacing(20);
        thrustSlider.setMinorTickSpacing(5);
        thrustSlider.setPaintTicks(true);
        thrustSlider.setPaintLabels(true);
        thrustSlider.addChangeListener(e -> {
            thrustLevel = thrustSlider.getValue() / 100.0f;
            if (canvas != null) {
                canvas.display();
            }
        });
        
        // Add start/stop button
        JButton startStopButton = new JButton("Start Simulation");
        startStopButton.addActionListener(e -> {
            isSimulationRunning = !isSimulationRunning;
            startStopButton.setText(isSimulationRunning ? "Stop Simulation" : "Start Simulation");
            if (isSimulationRunning) {
                animator.start();
            } else {
                animator.stop();
            }
        });

        controlPanel.add(new JLabel("Thrust:"));
        controlPanel.add(thrustSlider);
        controlPanel.add(startStopButton);

        // Add panels to main panel
        add(controlPanel, BorderLayout.NORTH);
        add(canvas, BorderLayout.CENTER);

        setupMouseControls();
    }

    private void setupMouseControls() {
        canvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastPoint = e.getPoint();
            }
        });

        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                Point newPoint = e.getPoint();
                rotY += (newPoint.x - lastPoint.x) * 0.5f;
                rotX += (newPoint.y - lastPoint.y) * 0.5f;
                lastPoint = newPoint;
                canvas.display();
            }
        });

        canvas.addMouseWheelListener(e -> {
            zoom += e.getWheelRotation() * 2.0f;
            canvas.display();
        });
    }

    private void initializeParticles() {
        for (int i = 0; i < NUM_PARTICLES; i++) {
            resetParticle(i);
            // Randomize initial positions
            particlePositions[i * 3] = (float) (Math.random() * 2.0 - 1.0);
            particlePositions[i * 3 + 1] = (float) (Math.random() * 2.0 - 1.0);
            particlePositions[i * 3 + 2] = (float) (Math.random() * 2.0 - 1.0);
        }
    }

    private void resetParticle(int index) {
        particlePositions[index * 3] = 3.0f;     // Start at thruster exit
        particlePositions[index * 3 + 1] = (float) (Math.random() * 0.5 - 0.25);
        particlePositions[index * 3 + 2] = (float) (Math.random() * 0.5 - 0.25);
        
        particleVelocities[index * 3] = 0.3f + (float) Math.random() * 0.2f;
        particleVelocities[index * 3 + 1] = (float) (Math.random() * 0.1 - 0.05);
        particleVelocities[index * 3 + 2] = (float) (Math.random() * 0.1 - 0.05);
        
        particleSizes[index] = 0.1f + (float) Math.random() * 0.2f;
    }

    @Override
    public void init(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClearColor(0.0f, 0.0f, 0.2f, 1.0f);
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glEnable(GL2.GL_COLOR_MATERIAL);
        gl.glEnable(GL2.GL_BLEND);
        gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
        
        // Set up lighting
        float[] lightPosition = {-10.0f, 10.0f, 10.0f, 1.0f};
        float[] lightAmbient = {0.2f, 0.2f, 0.2f, 1.0f};
        float[] lightDiffuse = {1.0f, 1.0f, 1.0f, 1.0f};
        float[] lightSpecular = {1.0f, 1.0f, 1.0f, 1.0f};
        
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, lightPosition, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, lightAmbient, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, lightDiffuse, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_SPECULAR, lightSpecular, 0);
        
        // Initialize GLU and quadric
        glu = new GLU();
        quadric = glu.gluNewQuadric();
        glu.gluQuadricNormals(quadric, GLU.GLU_SMOOTH);
        glu.gluQuadricTexture(quadric, true);
        
        // Create and start animator
        animator = new FPSAnimator(canvas, FPS);
    }

    @Override
    public void display(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();

        // Set up camera
        gl.glTranslatef(0.0f, 0.0f, zoom);
        gl.glRotatef(rotX, 1.0f, 0.0f, 0.0f);
        gl.glRotatef(rotY, 0.0f, 1.0f, 0.0f);

        // Draw thruster body
        drawThrusterBody(gl);

        // Draw exhaust plume
        if (thrustLevel > 0.0f) {
            drawExhaustPlume(gl);
            updateParticles();
            drawParticles(gl);
        }

        // Rotate continuously if simulation is running
        if (isSimulationRunning) {
            rotationAngle += 1.0f;
            if (rotationAngle > 360.0f) {
                rotationAngle = 0.0f;
            }
        }
    }

    private void drawThrusterBody(GL2 gl) {
        // Main body
        gl.glPushMatrix();
        gl.glRotatef(90, 0.0f, 1.0f, 0.0f);
        
        // Set material properties for metallic look
        float[] matAmbient = {0.5f, 0.5f, 0.5f, 1.0f};
        float[] matDiffuse = {0.7f, 0.7f, 0.7f, 1.0f};
        float[] matSpecular = {1.0f, 1.0f, 1.0f, 1.0f};
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_AMBIENT, matAmbient, 0);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, matDiffuse, 0);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_SPECULAR, matSpecular, 0);
        gl.glMaterialf(GL2.GL_FRONT, GL2.GL_SHININESS, 100.0f);
        
        // Draw main cylinder
        glu.gluCylinder(quadric, 1.0, 1.0, 3.0, 32, 1);
        
        // Draw nozzle
        gl.glTranslatef(0.0f, 0.0f, 3.0f);
        glu.gluCylinder(quadric, 1.0, 1.5, 1.0, 32, 1);
        
        // Draw end caps
        gl.glTranslatef(0.0f, 0.0f, 1.0f);
        glu.gluDisk(quadric, 0.0, 1.5, 32, 1);
        gl.glTranslatef(0.0f, 0.0f, -4.0f);
        glu.gluDisk(quadric, 0.0, 1.0, 32, 1);
        
        gl.glPopMatrix();
    }

    private void drawExhaustPlume(GL2 gl) {
        gl.glPushMatrix();
        gl.glTranslatef(3.0f, 0.0f, 0.0f);
        gl.glRotatef(90, 0.0f, 1.0f, 0.0f);
        
        // Set material properties for exhaust plume
        float alpha = 0.3f + (thrustLevel * 0.4f);
        float[] exhaustColor = {1.0f, 0.6f + (thrustLevel * 0.4f), 0.0f, alpha};
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_AMBIENT_AND_DIFFUSE, exhaustColor, 0);
        
        float length = 2.0f + (thrustLevel * 6.0f);
        glu.gluCylinder(quadric, 1.0, 0.1f, length, 32, 1);
        
        gl.glPopMatrix();
    }

    private void updateParticles() {
        for (int i = 0; i < NUM_PARTICLES; i++) {
            // Update positions
            particlePositions[i * 3] += particleVelocities[i * 3] * thrustLevel;
            particlePositions[i * 3 + 1] += particleVelocities[i * 3 + 1] * thrustLevel;
            particlePositions[i * 3 + 2] += particleVelocities[i * 3 + 2] * thrustLevel;
            
            // Reset particle if it's too far
            if (particlePositions[i * 3] > 10.0f) {
                resetParticle(i);
            }
        }
    }

    private void drawParticles(GL2 gl) {
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_POINT_SMOOTH);
        gl.glPointSize(3.0f);
        
        gl.glBegin(GL2.GL_POINTS);
        for (int i = 0; i < NUM_PARTICLES; i++) {
            float alpha = 1.0f - (particlePositions[i * 3] - 3.0f) / 7.0f;
            if (alpha < 0) alpha = 0;
            gl.glColor4f(1.0f, 0.6f, 0.0f, alpha * thrustLevel);
            gl.glVertex3f(
                particlePositions[i * 3],
                particlePositions[i * 3 + 1],
                particlePositions[i * 3 + 2]
            );
        }
        gl.glEnd();
        
        gl.glEnable(GL2.GL_LIGHTING);
    }

    @Override
    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        float aspect = (float) width / height;
        glu.gluPerspective(45.0, aspect, 0.1, 100.0);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    @Override
    public void dispose(GLAutoDrawable drawable) {
        if (animator != null && animator.isAnimating()) {
            animator.stop();
        }
        if (quadric != null) {
            glu.gluDeleteQuadric(quadric);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                rotY -= 5.0f;
                break;
            case KeyEvent.VK_RIGHT:
                rotY += 5.0f;
                break;
            case KeyEvent.VK_UP:
                rotX -= 5.0f;
                break;
            case KeyEvent.VK_DOWN:
                rotX += 5.0f;
                break;
            case KeyEvent.VK_PLUS:
            case KeyEvent.VK_EQUALS:
                zoom += 1.0f;
                break;
            case KeyEvent.VK_MINUS:
                zoom -= 1.0f;
                break;
        }
        if (canvas != null) {
            canvas.display();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public void setThrustLevel(float level) {
        this.thrustLevel = Math.max(0.0f, Math.min(1.0f, level));
        if (canvas != null) {
            canvas.display();
        }
    }
} 