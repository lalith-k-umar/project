package com.jetthruster.model;

// This class demonstrates composition - ThrusterMonitor is a part of TurbofanThruster
public class ThrusterMonitor {
    private final IThrusterControl thruster;
    private double maxTemperature;
    private double maxFuelFlow;
    private boolean isWarning;

    public ThrusterMonitor(IThrusterControl thruster) {
        this.thruster = thruster;
        this.maxTemperature = 1500.0; // Default max temperature in Kelvin
        this.maxFuelFlow = 1.5; // Default max fuel flow in kg/s
        this.isWarning = false;
    }

    public void updateStatus(FlightEnvironment environment) {
        double currentTemp = calculateOperatingTemperature();
        double currentFuelFlow = thruster.getFuelConsumption();
        
        isWarning = currentTemp > maxTemperature || currentFuelFlow > maxFuelFlow;
    }

    private double calculateOperatingTemperature() {
        // Simplified temperature calculation based on thrust level and afterburner
        double baseTemp = 800.0 + (thruster.getThrustLevel() * 500.0);
        return thruster.isAfterburnerEnabled() ? baseTemp * 1.5 : baseTemp;
    }

    public boolean isWarning() {
        return isWarning;
    }

    public void setMaxTemperature(double maxTemperature) {
        this.maxTemperature = maxTemperature;
    }

    public void setMaxFuelFlow(double maxFuelFlow) {
        this.maxFuelFlow = maxFuelFlow;
    }
}
