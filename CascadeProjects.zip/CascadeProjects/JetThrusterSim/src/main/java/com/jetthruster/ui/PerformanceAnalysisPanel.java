package com.jetthruster.ui;

import com.jetthruster.model.TurbofanThruster;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PerformanceAnalysisPanel extends JPanel {
    private final TurbofanThruster thruster;
    private final XYSeries thrustSeries;
    private final XYSeries efficiencySeries;
    private final XYSeries temperatureSeries;
    private final XYSeries pressureSeries;
    private final List<ChartPanel> chartPanels;
    private final Timer updateTimer;
    private static final int MAX_DATA_POINTS = 100;
    private long startTime;

    public PerformanceAnalysisPanel(TurbofanThruster thruster) {
        this.thruster = thruster;
        this.chartPanels = new ArrayList<>();
        this.startTime = System.currentTimeMillis();

        // Initialize data series
        thrustSeries = new XYSeries("Thrust (N)");
        efficiencySeries = new XYSeries("Efficiency (%)");
        temperatureSeries = new XYSeries("Temperature (K)");
        pressureSeries = new XYSeries("Pressure (Pa)");

        // Create charts
        createCharts();

        // Set up layout
        setLayout(new GridLayout(2, 2, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add charts to panel
        for (ChartPanel panel : chartPanels) {
            add(panel);
        }

        // Create update timer
        updateTimer = new Timer(100, e -> updateCharts());
        updateTimer.start();
    }

    private void createCharts() {
        // Thrust vs Time chart
        XYSeriesCollection thrustData = new XYSeriesCollection();
        thrustData.addSeries(thrustSeries);
        JFreeChart thrustChart = ChartFactory.createXYLineChart(
            "Thrust vs Time",
            "Time (s)",
            "Thrust (N)",
            thrustData,
            PlotOrientation.VERTICAL,
            true, true, false
        );
        chartPanels.add(new ChartPanel(thrustChart));

        // Efficiency vs Time chart
        XYSeriesCollection efficiencyData = new XYSeriesCollection();
        efficiencyData.addSeries(efficiencySeries);
        JFreeChart efficiencyChart = ChartFactory.createXYLineChart(
            "Efficiency vs Time",
            "Time (s)",
            "Efficiency (%)",
            efficiencyData,
            PlotOrientation.VERTICAL,
            true, true, false
        );
        chartPanels.add(new ChartPanel(efficiencyChart));

        // Temperature vs Time chart
        XYSeriesCollection temperatureData = new XYSeriesCollection();
        temperatureData.addSeries(temperatureSeries);
        JFreeChart temperatureChart = ChartFactory.createXYLineChart(
            "Temperature vs Time",
            "Time (s)",
            "Temperature (K)",
            temperatureData,
            PlotOrientation.VERTICAL,
            true, true, false
        );
        chartPanels.add(new ChartPanel(temperatureChart));

        // Pressure vs Time chart
        XYSeriesCollection pressureData = new XYSeriesCollection();
        pressureData.addSeries(pressureSeries);
        JFreeChart pressureChart = ChartFactory.createXYLineChart(
            "Pressure vs Time",
            "Time (s)",
            "Pressure (Pa)",
            pressureData,
            PlotOrientation.VERTICAL,
            true, true, false
        );
        chartPanels.add(new ChartPanel(pressureChart));
    }

    private void updateCharts() {
        double currentTime = (System.currentTimeMillis() - startTime) / 1000.0;
        
        // Get current simulation values
        double thrust = thruster.getCurrentThrust();
        double efficiency = thruster.getEfficiency() * 100.0;
        double temperature = thruster.getTemperature();
        double pressure = thruster.getPressure();

        // Add new data points
        thrustSeries.add(currentTime, thrust);
        efficiencySeries.add(currentTime, efficiency);
        temperatureSeries.add(currentTime, temperature);
        pressureSeries.add(currentTime, pressure);

        // Remove old data points if we exceed MAX_DATA_POINTS
        while (thrustSeries.getItemCount() > MAX_DATA_POINTS) {
            thrustSeries.remove(0);
            efficiencySeries.remove(0);
            temperatureSeries.remove(0);
            pressureSeries.remove(0);
        }

        // Update all charts
        for (ChartPanel panel : chartPanels) {
            panel.getChart().fireChartChanged();
        }
    }

    public void startSimulation() {
        startTime = System.currentTimeMillis();
        thrustSeries.clear();
        efficiencySeries.clear();
        temperatureSeries.clear();
        pressureSeries.clear();
        updateTimer.start();
    }

    public void stopSimulation() {
        updateTimer.stop();
    }

    public void dispose() {
        updateTimer.stop();
    }
} 