package com.jetthruster.model.mission;

import java.util.ArrayList;
import java.util.List;

public class MissionProfile {
    private final String name;
    private final List<MissionPhase> phases;
    private final double maxAltitude;
    private final double maxSpeed;
    private final double totalDistance;
    private int currentPhaseIndex;
    private MissionStatus status;

    public MissionProfile(String name, double maxAltitude, double maxSpeed, double totalDistance) {
        this.name = name;
        this.phases = new ArrayList<>();
        this.maxAltitude = maxAltitude;
        this.maxSpeed = maxSpeed;
        this.totalDistance = totalDistance;
        this.currentPhaseIndex = 0;
        this.status = MissionStatus.READY;
    }

    public void addPhase(MissionPhase phase) {
        phases.add(phase);
    }

    public void start() {
        if (status == MissionStatus.READY) {
            status = MissionStatus.IN_PROGRESS;
            currentPhaseIndex = 0;
        }
    }

    public void updateProgress(double currentAltitude, double currentSpeed, double distanceCovered) {
        if (status != MissionStatus.IN_PROGRESS) return;

        MissionPhase currentPhase = phases.get(currentPhaseIndex);
        currentPhase.updateProgress(currentAltitude, currentSpeed);

        if (currentPhase.isComplete()) {
            currentPhaseIndex++;
            if (currentPhaseIndex >= phases.size()) {
                status = MissionStatus.COMPLETED;
            }
        }
    }

    public MissionPhase getCurrentPhase() {
        return currentPhaseIndex < phases.size() ? phases.get(currentPhaseIndex) : null;
    }

    public double getCompletionPercentage() {
        if (status == MissionStatus.COMPLETED) return 100.0;
        if (status == MissionStatus.READY) return 0.0;

        double completedPhases = currentPhaseIndex;
        double currentPhaseProgress = getCurrentPhase() != null ? 
            getCurrentPhase().getCompletionPercentage() : 0;

        return (completedPhases + currentPhaseProgress / 100.0) / phases.size() * 100.0;
    }

    public String getName() {
        return name;
    }

    public MissionStatus getStatus() {
        return status;
    }

    public double getMaxAltitude() {
        return maxAltitude;
    }

    public double getMaxSpeed() {
        return maxSpeed;
    }

    public double getTotalDistance() {
        return totalDistance;
    }

    public List<MissionPhase> getPhases() {
        return new ArrayList<>(phases);
    }
}
