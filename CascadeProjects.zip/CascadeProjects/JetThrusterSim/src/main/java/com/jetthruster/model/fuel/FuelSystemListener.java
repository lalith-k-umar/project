package com.jetthruster.model.fuel;

public interface FuelSystemListener {
    void onFuelSystemEvent(FuelSystemEvent event, FuelManagementSystem fuelSystem);
}
