package com.jetthruster.exception;

public class WeatherSystemException extends ThrusterException {
    public WeatherSystemException(String message) {
        super(message);
    }

    public WeatherSystemException(String message, Throwable cause) {
        super(message, cause);
    }
} 