package com.jetthruster.model;

import java.util.ArrayList;
import java.util.List;

public class PerformanceLogger {
    private boolean running;
    private final List<PerformanceData> performanceHistory;
    private static final int MAX_HISTORY_SIZE = 1000;

    public PerformanceLogger() {
        this.running = false;
        this.performanceHistory = new ArrayList<>();
    }

    public void start() {
        this.running = true;
    }

    public void stop() {
        this.running = false;
    }

    public void logPerformance(Thruster thruster, FlightEnvironment environment) {
        PerformanceData data = new PerformanceData(
            System.currentTimeMillis(),
            thruster.getCurrentThrust(),
            thruster.getTemperature(),
            environment.getAltitude(),
            environment.getAirDensity(),
            thruster.getState()
        );

        performanceHistory.add(data);

        if (performanceHistory.size() > MAX_HISTORY_SIZE) {
            performanceHistory.remove(0);
        }
    }

    public void log(double thrust, double temperature, double altitude, double speed, double fuelLevel) {
        if (running) {
            performanceHistory.add(new PerformanceData(thrust, temperature, altitude, speed, fuelLevel));
        }
    }

    public List<PerformanceData> getPerformanceHistory() {
        return new ArrayList<>(performanceHistory);
    }

    public List<PerformanceData> getLogs() {
        return new ArrayList<>(performanceHistory);
    }

    public void clearHistory() {
        performanceHistory.clear();
    }

    private static class PerformanceData {
        private final long timestamp;
        private final double thrust;
        private final double temperature;
        private final double altitude;
        private final double airDensity;
        private final ThrusterState state;
        private final double speed;
        private final double fuelLevel;

        public PerformanceData(long timestamp, double thrust, double temperature, 
                              double altitude, double airDensity, ThrusterState state) {
            this.timestamp = timestamp;
            this.thrust = thrust;
            this.temperature = temperature;
            this.altitude = altitude;
            this.airDensity = airDensity;
            this.state = state;
            this.speed = 0;
            this.fuelLevel = 0;
        }

        public PerformanceData(double thrust, double temperature, double altitude, double speed, double fuelLevel) {
            this.timestamp = 0;
            this.thrust = thrust;
            this.temperature = temperature;
            this.altitude = altitude;
            this.airDensity = 0;
            this.state = null;
            this.speed = speed;
            this.fuelLevel = fuelLevel;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public double getThrust() {
            return thrust;
        }

        public double getTemperature() {
            return temperature;
        }

        public double getAltitude() {
            return altitude;
        }

        public double getAirDensity() {
            return airDensity;
        }

        public ThrusterState getState() {
            return state;
        }

        public double getSpeed() {
            return speed;
        }

        public double getFuelLevel() {
            return fuelLevel;
        }
    }
}
