package com.jetthruster.model;

public enum AlertLevel {
    INFO, WARNING, CRITICAL
}
