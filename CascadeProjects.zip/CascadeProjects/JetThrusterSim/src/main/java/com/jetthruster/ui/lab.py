def is_equivalence_relation():
    relation = [
    ["a","a"],
    ["b","b"],
    ["c","c"],
    ["d","d"],
    ["b","a"],
    ["a","b"],
    ["c","d"],
    ["d","a"],
]
    n = len(relation)
    
  
    for i in range(n):
        if relation[i][i] != 1:
            return False
    
  
    for i in range(n):
        for j in range(n):
            if relation[i][j] != relation[j][i]:
                return False
    

    for i in range(n):
        for j in range(n):
            for k in range(n):
                if relation[i][j] and relation[j][k] and not relation[i][k]:
                    return False
    
    return True



if is_equivalence_relation():
    print("The given relation is an equivalence relation.")
else:
    print("The given relation is NOT an equivalence relation.")
