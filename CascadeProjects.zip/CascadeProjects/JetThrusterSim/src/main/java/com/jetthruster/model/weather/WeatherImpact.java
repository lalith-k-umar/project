package com.jetthruster.model.weather;

public class WeatherImpact {
    private final double temperatureImpact;
    private final double windImpact;
    private final double humidityImpact;
    private final double thrustImpact;
    private final double fuelEfficiencyImpact;
    private final double stabilityImpact;

    public WeatherImpact(double temperatureImpact, double windImpact, double humidityImpact, double thrustImpact, double fuelEfficiencyImpact, double stabilityImpact) {
        this.temperatureImpact = temperatureImpact;
        this.windImpact = windImpact;
        this.humidityImpact = humidityImpact;
        this.thrustImpact = thrustImpact;
        this.fuelEfficiencyImpact = fuelEfficiencyImpact;
        this.stabilityImpact = stabilityImpact;
    }

    public double getTemperatureImpact() {
        return temperatureImpact;
    }

    public double getWindImpact() {
        return windImpact;
    }

    public double getHumidityImpact() {
        return humidityImpact;
    }

    public double getThrustImpact() {
        return thrustImpact;
    }

    public double getFuelEfficiencyImpact() {
        return fuelEfficiencyImpact;
    }

    public double getStabilityImpact() {
        return stabilityImpact;
    }

    public double getTotalImpact() {
        return (temperatureImpact + windImpact + humidityImpact + thrustImpact + fuelEfficiencyImpact + stabilityImpact) / 6.0;
    }
}
