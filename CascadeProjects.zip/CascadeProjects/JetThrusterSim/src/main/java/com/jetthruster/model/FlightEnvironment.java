package com.jetthruster.model;

public class FlightEnvironment {
    private double altitude;
    private double temperature;
    private double airDensity;

    public FlightEnvironment() {
        this.altitude = 0.0;
        this.temperature = 15.0;
        calculateAirDensity();
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
        calculateAirDensity();
    }

    public double getAltitude() {
        return altitude;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        calculateAirDensity();
    }

    public double getTemperature() {
        return temperature;
    }

    public double getAirDensity() {
        return airDensity;
    }

    private void calculateAirDensity() {
        // Simple air density model based on altitude and temperature
        double standardTemp = 288.15 - (0.0065 * altitude);
        double standardPressure = 101325.0 * Math.pow(1 - (0.0065 * altitude) / 288.15, 5.2561);
        airDensity = standardPressure / (287.05 * (standardTemp + (temperature - 15)));
    }

    public void update() {
        calculateAirDensity();
    }
}
