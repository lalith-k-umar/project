package com.jetthruster.ui;

import com.jetthruster.model.TurbofanThruster;
import com.jetthruster.model.FlightEnvironment;

import javax.swing.*;
import java.awt.*;

public class SimpleUI extends JFrame {
    private final TurbofanThruster thruster;
    private final FlightEnvironment environment;
    private JSlider thrustSlider;
    private JTextArea outputArea;

    public SimpleUI() {
        super("Simple Thruster Simulation");
        
        // Initialize components
        thruster = new TurbofanThruster(8.0);
        environment = new FlightEnvironment();
        
        // Setup UI
        setupUI();
        
        // Configure window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
    }

    private void setupUI() {
        setLayout(new BorderLayout(10, 10));
        
        // Control panel
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        controlPanel.setBorder(BorderFactory.createTitledBorder("Controls"));

        // Thrust slider
        thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setMajorTickSpacing(20);
        thrustSlider.setMinorTickSpacing(5);
        thrustSlider.setPaintTicks(true);
        thrustSlider.setPaintLabels(true);
        thrustSlider.setBorder(BorderFactory.createTitledBorder("Thrust Level (%)"));
        
        // Add components to control panel
        controlPanel.add(thrustSlider);
        
        // Output area
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Output"));

        // Add panels to frame
        add(controlPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);
        
        // Add slider listener
        thrustSlider.addChangeListener(e -> updateSimulation());
    }

    private void updateSimulation() {
        try {
            // Update thruster
            double thrustLevel = thrustSlider.getValue() / 100.0;
            thruster.setThrustLevel(thrustLevel);
            
            // Calculate thrust
            thruster.calculateThrust(environment);
            
            // Update display
            StringBuilder sb = new StringBuilder();
            sb.append("Simulation Status:\n");
            sb.append(String.format("Thrust Level: %.1f%%\n", thrustLevel * 100));
            sb.append(String.format("Current Thrust: %.2f kN\n", thruster.getCurrentThrust()));
            sb.append(String.format("Fuel Consumption: %.2f kg/s\n", thruster.getFuelConsumption()));
            sb.append(String.format("Efficiency: %.1f%%\n", thruster.getEfficiency()));
            
            outputArea.setText(sb.toString());
        } catch (Exception e) {
            outputArea.setText("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            SimpleUI ui = new SimpleUI();
            ui.setVisible(true);
        });
    }
} 