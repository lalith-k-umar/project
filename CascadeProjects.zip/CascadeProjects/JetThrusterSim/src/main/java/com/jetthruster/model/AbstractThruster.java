package com.jetthruster.model;

public abstract class AbstractThruster implements IThrusterControl {
    protected double thrustLevel;
    protected double currentThrust;
    protected boolean afterburnerEnabled;
    protected double fuelConsumption;

    public AbstractThruster() {
        this.thrustLevel = 0.0;
        this.currentThrust = 0.0;
        this.afterburnerEnabled = false;
        this.fuelConsumption = 0.0;
    }

    @Override
    public void setThrustLevel(double level) {
        if (level < 0 || level > 1) {
            throw new IllegalArgumentException("Thrust level must be between 0 and 1");
        }
        this.thrustLevel = level;
        calculateFuelConsumption();
    }

    @Override
    public double getThrustLevel() {
        return thrustLevel;
    }

    @Override
    public void setAfterburnerEnabled(boolean enabled) {
        this.afterburnerEnabled = enabled;
        calculateFuelConsumption();
    }

    @Override
    public boolean isAfterburnerEnabled() {
        return afterburnerEnabled;
    }

    @Override
    public double getCurrentThrust() {
        return currentThrust;
    }

    @Override
    public double getFuelConsumption() {
        return fuelConsumption;
    }

    protected void setCurrentThrust(double thrust) {
        this.currentThrust = thrust;
    }

    protected void setFuelConsumption(double consumption) {
        this.fuelConsumption = consumption;
    }

    public double getEfficiency() {
        // Calculate efficiency based on thrust and fuel consumption
        // Higher thrust and lower fuel consumption means higher efficiency
        double efficiency = (currentThrust / (fuelConsumption * 1000.0)) * 100.0;
        return Math.min(100.0, efficiency); // Cap at 100%
    }

    public double getTemperature() {
        // Calculate temperature based on thrust level and afterburner status
        double baseTemp = 300.0; // Base temperature in Kelvin
        double thrustTemp = thrustLevel * 500.0; // Temperature increase with thrust
        double afterburnerTemp = afterburnerEnabled ? 800.0 : 0.0; // Additional temperature from afterburner
        return baseTemp + thrustTemp + afterburnerTemp;
    }

    public double getPressure() {
        // Calculate pressure based on thrust level and afterburner status
        double basePressure = 101325.0; // Base pressure in Pa (1 atm)
        double thrustPressure = thrustLevel * 50000.0; // Pressure increase with thrust
        double afterburnerPressure = afterburnerEnabled ? 100000.0 : 0.0; // Additional pressure from afterburner
        return basePressure + thrustPressure + afterburnerPressure;
    }

    protected abstract void calculateFuelConsumption();
}
