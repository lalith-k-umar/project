package com.jetthruster;

import com.jetthruster.model.*;
import com.jetthruster.model.weather.WeatherSystem;
import com.jetthruster.ui.MainUI;

public class JetThrusterSimulator {
    private TurbofanThruster thruster;
    private FlightEnvironment environment;
    private DiagnosticSystem diagnosticSystem;
    private WeatherSystem weatherSystem;

    public JetThrusterSimulator() {
        initializeSystems();
    }

    private void initializeSystems() {
        thruster = new TurbofanThruster(8.0);
        environment = new FlightEnvironment();
        diagnosticSystem = new DiagnosticSystem();
        weatherSystem = new WeatherSystem();
    }

    public void runSimulation() {
        // Set initial conditions
        environment.setAltitude(1000);
        environment.setTemperature(15);
        thruster.setThrustLevel(0.5);

        // Update systems
        environment.update();
        thruster.calculateThrust(environment);
        diagnosticSystem.checkSystem(thruster, environment);

        // Print status
        System.out.println("=== Jet Thruster Simulation ===");
        System.out.printf("Thrust Level: %.1f%%\n", thruster.getThrustLevel() * 100);
        System.out.printf("Current Thrust: %.2f kN\n", thruster.getCurrentThrust());
        System.out.printf("Altitude: %.0f m\n", environment.getAltitude());
        System.out.printf("Temperature: %.1f°C\n", environment.getTemperature());
        System.out.printf("Fuel Consumption: %.2f kg/s\n", thruster.getFuelConsumption());
        System.out.println("\nDiagnostic Message:");
        System.out.println(diagnosticSystem.getLastDiagnosticMessage());
    }

    public static void main(String[] args) {
        // Always launch GUI version
        javax.swing.SwingUtilities.invokeLater(() -> new MainUI());
    }
}
