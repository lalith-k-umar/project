package com.jetthruster.model;

public interface IThruster {
    void setThrustLevel(double level);
    double getThrustLevel();
    void setAfterburnerEnabled(boolean enabled);
    boolean isAfterburnerEnabled();
    void calculateThrust(FlightEnvironment environment);
    double getCurrentThrust();
    double getFuelConsumption();
    double getEfficiency();
    double getTemperature();
    double getPressure();
} 