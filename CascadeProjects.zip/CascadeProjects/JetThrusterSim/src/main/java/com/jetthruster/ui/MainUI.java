package com.jetthruster.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.jetthruster.visualization.ThrusterVisualization;

public class MainUI extends JFrame {
    private final ThrusterVisualization visualization;
    private final JSlider thrustSlider;
    private final JToggleButton afterburnerButton;
    private final JLabel statusLabel;

    public MainUI() {
        setTitle("Jet Thruster Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create components
        visualization = new ThrusterVisualization();
        thrustSlider = new JSlider(JSlider.VERTICAL, 0, 100, 0);
        afterburnerButton = new JToggleButton("Afterburner");
        statusLabel = new JLabel("Thrust: 0%");
        
        // Configure slider
        thrustSlider.setMajorTickSpacing(20);
        thrustSlider.setMinorTickSpacing(5);
        thrustSlider.setPaintTicks(true);
        thrustSlider.setPaintLabels(true);
        
        // Layout
        setLayout(new BorderLayout());
        
        // Add visualization panel in center
        add(visualization.getVisualizationPanel(), BorderLayout.CENTER);
        
        // Create control panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        controlPanel.add(thrustSlider, BorderLayout.CENTER);
        controlPanel.add(afterburnerButton, BorderLayout.SOUTH);
        add(controlPanel, BorderLayout.EAST);
        
        // Add status panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.add(statusLabel);
        add(statusPanel, BorderLayout.SOUTH);
        
        // Add listeners
        thrustSlider.addChangeListener(e -> {
            double thrustLevel = thrustSlider.getValue() / 100.0;
            visualization.updateThrustLevel(thrustLevel);
            statusLabel.setText(String.format("Thrust: %.0f%%", thrustLevel * 100));
        });
        
        afterburnerButton.addActionListener(e -> {
            visualization.setAfterburnerEnabled(afterburnerButton.isSelected());
        });
        
        // Set size and start visualization
        setSize(800, 600);
        visualization.startAnimation();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new MainUI().setVisible(true);
        });
    }
}