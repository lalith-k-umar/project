package com.jetthruster.model.weather;

public class WeatherSystemException extends RuntimeException {
    public WeatherSystemException(String message) {
        super(message);
    }

    public WeatherSystemException(String message, Throwable cause) {
        super(message, cause);
    }
}
