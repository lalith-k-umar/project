package com.jetthruster.model.fuel;

import com.jetthruster.model.fuel.TankStatus;

public class FuelTank {
    private final String name;
    private final double capacity;
    private double currentLevel;
    private final FuelTankType type;
    private TankStatus status;
    private static final double FUEL_DENSITY = 0.8; // kg/L (approximate density of jet fuel)

    public FuelTank(String name, double capacity, FuelTankType type) {
        this.name = name;
        this.capacity = capacity;
        this.currentLevel = capacity;
        this.type = type;
        this.status = TankStatus.OPERATIONAL;
    }

    public double withdraw(double amount) {
        if (status != TankStatus.OPERATIONAL) {
            return 0;
        }

        double actualWithdrawal = Math.min(currentLevel, amount);
        currentLevel -= actualWithdrawal;
        
        if (currentLevel < capacity * 0.1) {
            status = TankStatus.CRITICAL;
        }
        
        return actualWithdrawal;
    }

    public void refill(double amount) {
        currentLevel = Math.min(capacity, currentLevel + amount);
        if (currentLevel > capacity * 0.1) {
            status = TankStatus.OPERATIONAL;
        }
    }

    public void consumeFuel(double amount) {
        withdraw(amount);
    }

    public void updateStatus() {
        if (currentLevel < capacity * 0.1) {
            status = TankStatus.CRITICAL;
        } else if (currentLevel < capacity * 0.25) {
            status = TankStatus.WARNING;
        } else {
            status = TankStatus.OPERATIONAL;
        }
    }

    public double getFuelDensity() {
        return FUEL_DENSITY;
    }

    public String getName() {
        return name;
    }

    public double getCapacity() {
        return capacity;
    }

    public double getCurrentLevel() {
        return currentLevel;
    }

    public FuelTankType getType() {
        return type;
    }

    public TankStatus getStatus() {
        return status;
    }
}
