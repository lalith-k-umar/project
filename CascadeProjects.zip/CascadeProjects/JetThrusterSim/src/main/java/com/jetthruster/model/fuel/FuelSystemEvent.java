package com.jetthruster.model.fuel;

public class FuelSystemEvent {
    private final FuelTank tank;
    private final String eventType;
    private final double oldValue;
    private final double newValue;

    public FuelSystemEvent(FuelTank tank, String eventType, double oldValue, double newValue) {
        this.tank = tank;
        this.eventType = eventType;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public FuelTank getTank() {
        return tank;
    }

    public String getEventType() {
        return eventType;
    }

    public double getOldValue() {
        return oldValue;
    }

    public double getNewValue() {
        return newValue;
    }
}
