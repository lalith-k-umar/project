package com.jetthruster.ui;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.glu.GLUquadric;
import com.jogamp.opengl.util.FPSAnimator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ThrusterVisualization implements GLEventListener {
    private static float rotationAngle = 0.0f;
    private static float thrustLevel = 0.0f;
    private static final GLU glu = new GLU();
    private float zoom = -15.0f;
    private float rotX = 0.0f;
    private float rotY = 0.0f;
    private Point lastPoint;
    private GLUquadric quadric;
    private final GLCanvas canvas;
    private final FPSAnimator animator;

    public ThrusterVisualization() {
        // Create OpenGL profile and capabilities
        GLProfile glProfile = GLProfile.getDefault();
        GLCapabilities glCapabilities = new GLCapabilities(glProfile);
        glCapabilities.setDoubleBuffered(true);
        glCapabilities.setHardwareAccelerated(true);

        // Create canvas and animator first
        canvas = new GLCanvas(glCapabilities);
        animator = new FPSAnimator(canvas, 60);

        // Then add event listeners
        canvas.addGLEventListener(this);

        // Add mouse listeners for rotation and zoom
        canvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastPoint = e.getPoint();
            }
        });

        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                Point newPoint = e.getPoint();
                rotY += (newPoint.x - lastPoint.x) * 0.5f;
                rotX += (newPoint.y - lastPoint.y) * 0.5f;
                lastPoint = newPoint;
                canvas.display();
            }
        });

        canvas.addMouseWheelListener(e -> {
            zoom += e.getWheelRotation();
            canvas.display();
        });

        // Start animator
        animator.start();
    }

    public Component getCanvas() {
        return canvas;
    }

    public void setThrustLevel(float level) {
        thrustLevel = Math.max(0.0f, Math.min(1.0f, level));
        if (canvas != null) {
            canvas.display();
        }
    }

    @Override
    public void init(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClearColor(0.0f, 0.0f, 0.2f, 1.0f);
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glEnable(GL2.GL_COLOR_MATERIAL);

        // Initialize quadric for drawing cylinders and spheres
        quadric = glu.gluNewQuadric();
        glu.gluQuadricDrawStyle(quadric, GLU.GLU_FILL);
        glu.gluQuadricNormals(quadric, GLU.GLU_SMOOTH);
    }

    @Override
    public void dispose(GLAutoDrawable drawable) {
        if (quadric != null) {
            glu.gluDeleteQuadric(quadric);
        }
        if (animator != null && animator.isAnimating()) {
            animator.stop();
        }
    }

    @Override
    public void display(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();

        // Set up camera
        gl.glTranslatef(0.0f, 0.0f, zoom);
        gl.glRotatef(rotX, 1.0f, 0.0f, 0.0f);
        gl.glRotatef(rotY, 0.0f, 1.0f, 0.0f);

        // Draw thruster body
        gl.glColor3f(0.7f, 0.7f, 0.7f);
        gl.glPushMatrix();
        gl.glRotatef(90, 0.0f, 1.0f, 0.0f);
        glu.gluCylinder(quadric, 1.0, 1.0, 3.0, 32, 32);
        gl.glPopMatrix();

        // Draw thrust effect
        if (thrustLevel > 0.0f) {
            gl.glPushMatrix();
            gl.glTranslatef(3.0f, 0.0f, 0.0f);
            gl.glRotatef(90, 0.0f, 1.0f, 0.0f);
            
            float[] thrustColor = {1.0f, 0.6f, 0.0f, 0.7f};
            gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_AMBIENT_AND_DIFFUSE, thrustColor, 0);
            
            float thrustLength = 2.0f + (thrustLevel * 4.0f);
            glu.gluCylinder(quadric, 1.0, 0.2, thrustLength, 32, 32);
            gl.glPopMatrix();
        }

        // Rotate continuously
        rotationAngle += 1.0f;
        if (rotationAngle > 360.0f) {
            rotationAngle = 0.0f;
        }
    }

    @Override
    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        float aspect = (float) width / height;
        glu.gluPerspective(45.0, aspect, 0.1, 100.0);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void stop() {
        if (animator != null && animator.isAnimating()) {
            animator.stop();
        }
    }
}
