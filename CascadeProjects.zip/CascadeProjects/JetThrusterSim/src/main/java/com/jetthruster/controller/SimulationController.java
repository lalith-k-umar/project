package com.jetthruster.controller;

import com.jetthruster.model.*;
import com.jetthruster.model.weather.WeatherSystem;
import com.jetthruster.model.weather.WeatherCondition;
import com.jetthruster.model.fuel.FuelManagementSystem;
import com.jetthruster.exception.WeatherSystemException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.List;

public class SimulationController {
    private final TurbofanThruster thruster;
    private final WeatherSystem weatherSystem;
    private final FuelManagementSystem fuelSystem;
    private final DiagnosticSystem diagnostics;
    private final PerformanceLogger performanceLogger;
    private final FlightEnvironment environment;
    private Timer simulationTimer;
    private boolean isRunning;

    public SimulationController() {
        this.thruster = new TurbofanThruster(5.0); // High bypass ratio for efficiency
        this.weatherSystem = new WeatherSystem();
        this.fuelSystem = new FuelManagementSystem();
        this.diagnostics = new DiagnosticSystem();
        this.performanceLogger = new PerformanceLogger();
        this.environment = new FlightEnvironment();
        this.isRunning = false;
    }

    public void setThrustLevel(double level) {
        if (isRunning && level >= 0 && level <= 1.0) {
            thruster.setThrustLevel(level);
        }
    }

    public void toggleAfterburner(boolean enabled) {
        if (isRunning) {
            thruster.setAfterburnerEnabled(enabled);
        }
    }

    public void start() throws WeatherSystemException {
        if (!isRunning) {
            fuelSystem.initialize();
            diagnostics.start();
            performanceLogger.start();
            
            simulationTimer = new Timer();
            simulationTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    try {
                        updateSimulation();
                    } catch (WeatherSystemException e) {
                        System.err.println("Weather system error: " + e.getMessage());
                        stop();
                    }
                }
            }, 0, 100); // Update every 100ms
            
            isRunning = true;
        }
    }

    public void stop() {
        if (isRunning) {
            simulationTimer.cancel();
            diagnostics.stop();
            performanceLogger.stop();
            isRunning = false;
        }
    }

    private void updateSimulation() throws WeatherSystemException {
        WeatherCondition conditions = weatherSystem.getCurrentConditions();
        environment.setTemperature(conditions.getTemperature());
        environment.setAltitude(environment.getAltitude() + calculateAltitudeChange());
        
        // Update thruster
        thruster.calculateThrust(environment);
        
        // Update fuel system
        double fuelConsumption = thruster.getFuelConsumption();
        fuelSystem.updateFuel(fuelConsumption);
        
        // Update weather
        weatherSystem.updateWeather(environment.getAltitude());
        
        // Log performance
        performanceLogger.log(
            thruster.getCurrentThrust(),
            environment.getTemperature(),
            environment.getAltitude(),
            0.0, // No direct speed measurement from thruster
            fuelSystem.getFuelLevel()
        );
        
        // Check systems
        diagnostics.checkSystem(thruster, environment);
    }

    private double calculateAltitudeChange() {
        // Simple altitude change calculation based on thrust and current conditions
        double thrustFactor = thruster.getCurrentThrust() / (100.0 * 1.5); // Max thrust is 100kN * 1.5 with afterburner
        return thrustFactor * 0.1; // 0.1 meters per 100ms at full thrust
    }

    public double getCurrentThrust() {
        return thruster.getCurrentThrust();
    }

    public double getSpeed() {
        return 0.0; // Speed is not directly measured by thruster
    }

    public double getAltitude() {
        return environment.getAltitude();
    }

    public double getTemperature() {
        try {
            return weatherSystem.getCurrentConditions().getTemperature();
        } catch (WeatherSystemException e) {
            System.err.println("Error getting temperature: " + e.getMessage());
            return 0.0; // Return default temperature on error
        }
    }

    public double getFuelLevel() {
        return fuelSystem.getFuelLevel();
    }

    public boolean isRunning() {
        return isRunning;
    }

    public ThrusterAlert[] getWarnings() {
        List<ThrusterAlert> warnings = diagnostics.getWarnings();
        return warnings.toArray(new ThrusterAlert[warnings.size()]);
    }
}
