package com.jetthruster.model.weather;

import com.jetthruster.exception.WeatherSystemException;

public interface IWeatherSystem {
    void updateWeather(double altitude) throws WeatherSystemException;
    WeatherCondition getCurrentConditions() throws WeatherSystemException;
    WeatherImpact getWeatherImpact();
    void setTemperature(double temperature) throws WeatherSystemException;
    void setHumidity(double humidity) throws WeatherSystemException;
    void setWindSpeed(double windSpeed) throws WeatherSystemException;
    boolean isWeatherHazardous();
}