package com.jetthruster.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SimulationUI extends JPanel {
    private double currentThrust = 0.0;
    private double currentAltitude = 0.0;
    private double currentSpeed = 0.0;
    private double currentTemperature = 15.0;
    private boolean isSimulationRunning = false;
    private Timer simulationTimer;
    private JLabel statusLabel;
    private JLabel thrustLabel;
    private JLabel altitudeLabel;
    private JLabel speedLabel;
    private JLabel temperatureLabel;
    private Thruster3DPanel thruster3DPanel;

    public SimulationUI() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("Simulation Control"));

        // Create main content panel
        JPanel mainContentPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create control panel
        JPanel controlPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Thrust control
        gbc.gridx = 0;
        gbc.gridy = 0;
        controlPanel.add(new JLabel("Thrust (%):"), gbc);

        gbc.gridx = 1;
        JSlider thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setMajorTickSpacing(10);
        thrustSlider.setMinorTickSpacing(1);
        thrustSlider.setPaintTicks(true);
        thrustSlider.setPaintLabels(true);
        thrustSlider.addChangeListener(e -> {
            currentThrust = thrustSlider.getValue();
            updateLabels();
            if (thruster3DPanel != null) {
                thruster3DPanel.setThrustLevel((float) (currentThrust / 100.0));
            }
        });
        controlPanel.add(thrustSlider, gbc);

        // Altitude control
        gbc.gridx = 0;
        gbc.gridy = 1;
        controlPanel.add(new JLabel("Altitude (m):"), gbc);

        gbc.gridx = 1;
        JSlider altitudeSlider = new JSlider(0, 15000, 0);
        altitudeSlider.setMajorTickSpacing(1000);
        altitudeSlider.setMinorTickSpacing(100);
        altitudeSlider.setPaintTicks(true);
        altitudeSlider.setPaintLabels(true);
        altitudeSlider.addChangeListener(e -> {
            currentAltitude = altitudeSlider.getValue();
            updateLabels();
        });
        controlPanel.add(altitudeSlider, gbc);

        // Speed control
        gbc.gridx = 0;
        gbc.gridy = 2;
        controlPanel.add(new JLabel("Speed (m/s):"), gbc);

        gbc.gridx = 1;
        JSlider speedSlider = new JSlider(0, 1000, 0);
        speedSlider.setMajorTickSpacing(100);
        speedSlider.setMinorTickSpacing(10);
        speedSlider.setPaintTicks(true);
        speedSlider.setPaintLabels(true);
        speedSlider.addChangeListener(e -> {
            currentSpeed = speedSlider.getValue();
            updateLabels();
        });
        controlPanel.add(speedSlider, gbc);

        // Temperature control
        gbc.gridx = 0;
        gbc.gridy = 3;
        controlPanel.add(new JLabel("Temperature (°C):"), gbc);

        gbc.gridx = 1;
        JSlider temperatureSlider = new JSlider(-50, 50, 15);
        temperatureSlider.setMajorTickSpacing(10);
        temperatureSlider.setMinorTickSpacing(1);
        temperatureSlider.setPaintTicks(true);
        temperatureSlider.setPaintLabels(true);
        temperatureSlider.addChangeListener(e -> {
            currentTemperature = temperatureSlider.getValue();
            updateLabels();
        });
        controlPanel.add(temperatureSlider, gbc);

        // Start/Stop button
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        JButton startStopButton = new JButton("Start Simulation");
        startStopButton.addActionListener(e -> toggleSimulation(startStopButton));
        controlPanel.add(startStopButton, gbc);

        // Status panel
        JPanel statusPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        statusPanel.setBorder(BorderFactory.createTitledBorder("Status"));
        
        statusLabel = new JLabel("Status: Stopped");
        thrustLabel = new JLabel("Current Thrust: 0.0%");
        altitudeLabel = new JLabel("Current Altitude: 0.0 m");
        speedLabel = new JLabel("Current Speed: 0.0 m/s");
        temperatureLabel = new JLabel("Current Temperature: 15.0°C");

        statusPanel.add(statusLabel);
        statusPanel.add(thrustLabel);
        statusPanel.add(altitudeLabel);
        statusPanel.add(speedLabel);
        statusPanel.add(temperatureLabel);

        // Create 3D visualization panel
        thruster3DPanel = new Thruster3DPanel();

        // Add panels to main content panel
        mainContentPanel.add(controlPanel);
        mainContentPanel.add(statusPanel);

        // Add panels to main panel
        add(mainContentPanel, BorderLayout.WEST);
        add(thruster3DPanel, BorderLayout.CENTER);

        // Initialize simulation timer
        simulationTimer = new Timer(100, e -> updateSimulation());
    }

    private void toggleSimulation(JButton button) {
        if (isSimulationRunning) {
            stopSimulation(button);
        } else {
            startSimulation(button);
        }
    }

    private void startSimulation(JButton button) {
        isSimulationRunning = true;
        button.setText("Stop Simulation");
        statusLabel.setText("Status: Running");
        simulationTimer.start();
        if (thruster3DPanel != null) {
            thruster3DPanel.setVisible(true);
        }
    }

    private void stopSimulation(JButton button) {
        isSimulationRunning = false;
        button.setText("Start Simulation");
        statusLabel.setText("Status: Stopped");
        simulationTimer.stop();
        if (thruster3DPanel != null) {
            thruster3DPanel.setVisible(false);
        }
    }

    private void updateSimulation() {
        // Update simulation state
        currentThrust = Math.max(0, Math.min(100, currentThrust + (Math.random() - 0.5) * 2));
        currentAltitude = Math.max(0, Math.min(15000, currentAltitude + (Math.random() - 0.5) * 100));
        currentSpeed = Math.max(0, Math.min(1000, currentSpeed + (Math.random() - 0.5) * 10));
        currentTemperature = Math.max(-50, Math.min(50, currentTemperature + (Math.random() - 0.5) * 2));
        
        updateLabels();
        if (thruster3DPanel != null) {
            thruster3DPanel.setThrustLevel((float) (currentThrust / 100.0));
        }
    }

    private void updateLabels() {
        thrustLabel.setText(String.format("Current Thrust: %.1f%%", currentThrust));
        altitudeLabel.setText(String.format("Current Altitude: %.1f m", currentAltitude));
        speedLabel.setText(String.format("Current Speed: %.1f m/s", currentSpeed));
        temperatureLabel.setText(String.format("Current Temperature: %.1f°C", currentTemperature));
    }

    public double getCurrentThrust() {
        return currentThrust;
    }

    public double getCurrentAltitude() {
        return currentAltitude;
    }

    public double getCurrentSpeed() {
        return currentSpeed;
    }

    public double getCurrentTemperature() {
        return currentTemperature;
    }
} 