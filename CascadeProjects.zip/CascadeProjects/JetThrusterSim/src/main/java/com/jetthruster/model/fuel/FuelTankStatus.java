package com.jetthruster.model.fuel;

public class FuelTankStatus {
    private final String name;
    private final double level;
    private final double amount;
    private final FuelTankType type;

    public FuelTankStatus(String name, double level, double amount, FuelTankType type) {
        this.name = name;
        this.level = level;
        this.amount = amount;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public double getFuelLevel() {
        return level;
    }

    public double getAmount() {
        return amount;
    }

    public FuelTankType getType() {
        return type;
    }
}
