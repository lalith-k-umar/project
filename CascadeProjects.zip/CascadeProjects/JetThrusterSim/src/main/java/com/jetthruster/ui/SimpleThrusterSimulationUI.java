package com.jetthruster.ui;

import com.jetthruster.model.TurbofanThruster;
import com.jetthruster.model.FlightEnvironment;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SimpleThrusterSimulationUI extends JFrame {
    private final TurbofanThruster thruster;
    private final FlightEnvironment environment;
    
    private JSlider thrustSlider;
    private JSlider altitudeSlider;
    private JSlider temperatureSlider;
    private JTextArea diagnosticArea;
    private Timer updateTimer;
    private JLabel statusLabel;
    
    // Performance tracking
    private final XYSeries thrustSeries;
    private final XYSeries fuelSeries;
    private double timeElapsed = 0;
    private boolean isPaused = false;

    public SimpleThrusterSimulationUI() {
        super("Jet Thruster Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);

        // Initialize systems
        thruster = new TurbofanThruster(8.0);
        environment = new FlightEnvironment();
        
        // Initialize performance tracking
        thrustSeries = new XYSeries("Thrust");
        fuelSeries = new XYSeries("Fuel Consumption");

        setupUI();
        setupKeyboardShortcuts();
        startSimulation();
    }

    private void setupUI() {
        // Main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Left panel for controls
        JPanel controlPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createTitledBorder("Controls"));
        
        // Thrust control
        thrustSlider = new JSlider(0, 100, 0);
        thrustSlider.setBorder(BorderFactory.createTitledBorder("Thrust Level (%)"));
        thrustSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(thrustSlider);

        // Altitude control
        altitudeSlider = new JSlider(0, 15000, 0);
        altitudeSlider.setBorder(BorderFactory.createTitledBorder("Altitude (m)"));
        altitudeSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(altitudeSlider);

        // Temperature control
        temperatureSlider = new JSlider(-50, 50, 15);
        temperatureSlider.setBorder(BorderFactory.createTitledBorder("Temperature (°C)"));
        temperatureSlider.addChangeListener(e -> updateSimulation());
        controlPanel.add(temperatureSlider);

        // Diagnostic area
        diagnosticArea = new JTextArea(10, 30);
        diagnosticArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(diagnosticArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Diagnostics"));
        controlPanel.add(scrollPane);

        // Add control panel to main panel
        mainPanel.add(controlPanel, BorderLayout.WEST);

        // Create performance chart
        createPerformanceChart(mainPanel);

        // Add status bar
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(BorderFactory.createEtchedBorder());
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Handle cleanup on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopSimulation();
            }
        });
    }

    private void createPerformanceChart(JPanel mainPanel) {
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(thrustSeries);
        dataset.addSeries(fuelSeries);

        JFreeChart chart = ChartFactory.createXYLineChart(
            "Performance Metrics",
            "Time (s)",
            "Value",
            dataset,
            PlotOrientation.VERTICAL,
            true, true, false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(600, 400));
        chartPanel.setBorder(BorderFactory.createTitledBorder("Performance Analysis"));
        mainPanel.add(chartPanel, BorderLayout.CENTER);
    }

    private void setupKeyboardShortcuts() {
        // Pause/Resume shortcut
        getRootPane().registerKeyboardAction(
            e -> togglePause(),
            KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        // Reset shortcut
        getRootPane().registerKeyboardAction(
            e -> resetSimulation(),
            KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );
    }

    private void startSimulation() {
        updateTimer = new Timer(50, e -> {
            if (!isPaused) {
                updateSimulation();
            }
        });
        updateTimer.start();
        setVisible(true);
    }

    private void updateSimulation() {
        try {
            // Update thruster settings
            thruster.setThrustLevel(thrustSlider.getValue() / 100.0);
            
            // Update environment
            environment.setAltitude(altitudeSlider.getValue());
            environment.setTemperature(temperatureSlider.getValue() + 273.15); // Convert to Kelvin
            
            // Calculate thrust
            thruster.calculateThrust(environment);
            
            // Update performance data
            timeElapsed += 0.05; // 50ms = 0.05s
            thrustSeries.add(timeElapsed, thruster.getCurrentThrust());
            fuelSeries.add(timeElapsed, thruster.getFuelConsumption());
            
            // Update diagnostics
            updateDiagnostics();
            
            // Update status
            statusLabel.setText(String.format("Thrust: %.1f kN, Fuel: %.1f kg/s", 
                thruster.getCurrentThrust(), thruster.getFuelConsumption()));
        } catch (Exception e) {
            statusLabel.setText("Error: " + e.getMessage());
        }
    }

    private void updateDiagnostics() {
        StringBuilder sb = new StringBuilder();
        sb.append("System Status:\n");
        sb.append(String.format("Thrust Level: %.1f%%\n", thrustSlider.getValue()));
        sb.append(String.format("Altitude: %d m\n", altitudeSlider.getValue()));
        sb.append(String.format("Temperature: %d°C\n", temperatureSlider.getValue()));
        sb.append(String.format("Efficiency: %.1f%%\n", thruster.getEfficiency()));
        sb.append(String.format("Temperature: %.1f K\n", thruster.getTemperature()));
        sb.append(String.format("Pressure: %.1f Pa\n", thruster.getPressure()));
        diagnosticArea.setText(sb.toString());
    }

    private void stopSimulation() {
        if (updateTimer != null) {
            updateTimer.stop();
        }
    }

    private void togglePause() {
        isPaused = !isPaused;
        statusLabel.setText(isPaused ? "Simulation Paused" : "Simulation Running");
    }

    private void resetSimulation() {
        timeElapsed = 0;
        thrustSeries.clear();
        fuelSeries.clear();
        thrustSlider.setValue(0);
        altitudeSlider.setValue(0);
        temperatureSlider.setValue(15);
        updateSimulation();
        statusLabel.setText("Simulation Reset");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new SimpleThrusterSimulationUI();
        });
    }
} 