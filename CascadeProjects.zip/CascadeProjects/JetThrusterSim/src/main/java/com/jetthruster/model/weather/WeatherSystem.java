package com.jetthruster.model.weather;

import com.jetthruster.exception.WeatherSystemException;

public class WeatherSystem {
    private double temperature;
    private double humidity;
    private double pressure;
    private double windSpeed;
    private double windDirection;
    private double turbulenceLevel;
    private double altitude;

    public WeatherSystem() {
        // Initialize with standard conditions
        this.temperature = 15.0; // 15°C
        this.humidity = 60.0;    // 60%
        this.pressure = 1013.25; // 1013.25 hPa (standard sea level)
        this.windSpeed = 0.0;
        this.windDirection = 0.0;
        this.turbulenceLevel = 0.0;
        this.altitude = 0.0;
    }

    public void updateWeather(double altitude) throws WeatherSystemException {
        if (altitude < 0) {
            throw new WeatherSystemException("Altitude cannot be negative");
        }
        
        this.altitude = altitude;
        
        // Temperature decreases with altitude (approximately 6.5°C per 1000m)
        this.temperature = 15.0 - (altitude * 0.0065);
        
        // Pressure decreases with altitude (approximate model)
        this.pressure = 1013.25 * Math.exp(-altitude / 7400);
        
        // Humidity decreases with altitude (simplified model)
        this.humidity = Math.max(0, 60.0 - (altitude * 0.005));
        
        // Wind speed increases with altitude (simplified model)
        this.windSpeed = Math.min(100, windSpeed + (altitude * 0.01));
        
        // Add some randomization for realism
        addRandomVariation();
    }

    private void addRandomVariation() {
        // Add small random variations to make it more realistic
        temperature += (Math.random() - 0.5) * 2.0;
        humidity += (Math.random() - 0.5) * 5.0;
        pressure += (Math.random() - 0.5) * 2.0;
        windSpeed += (Math.random() - 0.5) * 3.0;
        windDirection += (Math.random() - 0.5) * 10.0;
        
        // Keep values in valid ranges
        humidity = Math.max(0, Math.min(100, humidity));
        pressure = Math.max(0, pressure);
        windSpeed = Math.max(0, windSpeed);
        windDirection = (windDirection + 360) % 360;
    }

    public void setTurbulenceLevel(double level) {
        if (level < 0 || level > 1) {
            throw new IllegalArgumentException("Turbulence level must be between 0 and 1");
        }
        this.turbulenceLevel = level;
    }

    public WeatherCondition getCurrentConditions() throws WeatherSystemException {
        WeatherCondition conditions = new WeatherCondition();
        conditions.setTemperature(temperature);
        conditions.setHumidity(humidity);
        conditions.setPressure(pressure);
        conditions.setWindSpeed(windSpeed);
        conditions.setWindDirection(windDirection);
        conditions.setTurbulenceLevel(turbulenceLevel);
        conditions.setAltitude(altitude);
        return conditions;
    }

    public void setManualWeather(double temperature, double humidity, double pressure) 
            throws WeatherSystemException {
        if (humidity < 0 || humidity > 100) {
            throw new WeatherSystemException("Humidity must be between 0 and 100");
        }
        if (pressure < 0) {
            throw new WeatherSystemException("Pressure cannot be negative");
        }
        
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
    }

    public void setWind(double speed, double direction) throws WeatherSystemException {
        if (speed < 0) {
            throw new WeatherSystemException("Wind speed cannot be negative");
        }
        if (direction < 0 || direction >= 360) {
            throw new WeatherSystemException("Wind direction must be between 0 and 359 degrees");
        }
        
        this.windSpeed = speed;
        this.windDirection = direction;
    }
}
