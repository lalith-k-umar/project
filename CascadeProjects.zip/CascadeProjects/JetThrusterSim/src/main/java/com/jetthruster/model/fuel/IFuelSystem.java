package com.jetthruster.model.fuel;

import com.jetthruster.exception.FuelSystemException;
import java.util.List;

public interface IFuelSystem {
    void addTank(FuelTank tank) throws FuelSystemException;
    void removeTank(FuelTank tank) throws FuelSystemException;
    void updateFuelStatus();
    void addListener(FuelSystemListener listener) throws FuelSystemException;
    void removeListener(FuelSystemListener listener);
    List<FuelTank> getTanks();
    double getTotalFuelLevel();
    boolean hasSufficientFuel(double requiredAmount) throws FuelSystemException;
}