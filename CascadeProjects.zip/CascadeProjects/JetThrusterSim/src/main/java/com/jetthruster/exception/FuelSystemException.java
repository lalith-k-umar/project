package com.jetthruster.exception;

public class FuelSystemException extends ThrusterException {
    public FuelSystemException(String message) {
        super(message);
    }

    public FuelSystemException(String message, Throwable cause) {
        super(message, cause);
    }
} 