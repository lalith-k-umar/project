#!/bin/bash

# Clean and compile the project
mvn clean compile

# Run the application
mvn exec:java -Dexec.mainClass="com.jetthruster.ui.EnhancedThrusterSimulationUI"
